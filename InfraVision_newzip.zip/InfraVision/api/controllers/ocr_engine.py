import sys
import json
import pdfplumber
import re

# --- HELPER FUNCTIONS ---
def clean_value(text):
    """Cleans whitespace and removes common noise characters."""
    if text is None: return ""
    # Replace multiple spaces/newlines with a single space and strip
    text = re.sub(r'\s+', ' ', str(text)).strip()
    return text

def parse_cost_table(table_data):
    """
    Parses the 'Estimated Cost Summary' table found at the end of the PDFs.
    """
    cost_data = {}
    if not table_data:
        return cost_data

    for row in table_data:
        # Clean row data: remove None and strip whitespace
        cleaned_row = [clean_value(cell) for cell in row if cell]
        
        # We expect rows like ["Civil Works", "125.50"]
        if len(cleaned_row) >= 2:
            desc = cleaned_row[0].lower()
            amount = cleaned_row[-1] # Amount is usually the last column

            # Map specific cost rows to JSON keys
            if "civil" in desc: cost_data['cost_civil_interior'] = amount
            elif "plumbing" in desc: cost_data['cost_plumbing'] = amount
            elif "fire" in desc: cost_data['cost_fire_fighting'] = amount
            elif "electrical" in desc: cost_data['cost_electrical'] = amount
            elif "hvac" in desc: cost_data['cost_hvac'] = amount
            elif "grand total" in desc: cost_data['cost_grand_total'] = amount
    
    return cost_data

# --- MAIN EXTRACTION LOGIC ---
def extract_data(pdf_path):
    extracted_data = {}
    full_text = ""
    all_tables = []

    try:
        with pdfplumber.open(pdf_path) as pdf:
            # 1. Extract Text and Tables from all pages
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    full_text += "\n" + text
                
                tables = page.extract_tables()
                for table in tables:
                    all_tables.append(table)

        # Normalize text for regex searching (keep newlines for field separation)
        full_text_search = full_text

        # --- 2. REGEX MAPPING (Tailored to your Dataset) ---
        # Maps JSON keys to Regex patterns found in N1, HN1, H1, D1
        regex_map = {
            # --- Project Overview ---
            "project_name": r"Project Name\s*[:\.]\s*(.*)",
            "location": r"Location\s*[:\.]\s*(.*)",
            "client": r"Client\s*[:\.]\s*(.*)",
            "consultant": r"Consultant\s*[:\.]\s*(.*)",
            "building_type": r"Building Type\s*[:\.]\s*(.*)",
            "total_built_up_area": r"Total Built-up Area\s*[:\.]\s*(.*?)Sq\.m",
            
            # --- Architectural & Parking (Critical for Risk) ---
            "parking_required": r"Parking.*?Required\s*[:\.]\s*(.*)",
            "parking_provided": r"Parking.*?Provided\s*[:\.]\s*(.*)",
            "fire_exits": r"Fire Exits\s*[:\.]\s*(.*)",
            
            # --- Structural Design (Critical for Seismic Safety) ---
            "structure_type": r"Structure Type\s*[:\.]\s*(.*)",
            "seismic_zone": r"Seismic Zone\s*[:\.]\s*(.*)",
            "concrete_grade": r"Concrete Grade\s*[:\.]\s*(.*)",
            "steel_grade": r"Steel Grade\s*[:\.]\s*(.*)",
            "soil_type": r"Soil Type\s*[:\.]\s*(.*)",
            
            # --- MEP Systems (Plumbing, Fire, HVAC, Electrical) ---
            "water_source": r"Water Supply.*?Source\s*[:\.]\s*(.*)",
            "stp_capacity": r"Sewage Treatment Plant.*?Capacity\s*[:\.]\s*(.*)",
            "fire_fighting_system": r"Fire Fighting System.*?System Components\s*[:\.]\s*(.*?)(?=Pumps|6\.)",
            "hvac_system": r"HVAC.*?System Type\s*[:\.]\s*(.*)",
            "electrical_load": r"Total HVAC Electrical Load\s*[:\.]\s*(.*)",
            "dg_sets": r"DG Sets\s*[:\.]\s*(.*)"
        }

        # Execute Regex Search
        for key, pattern in regex_map.items():
            # re.IGNORECASE: matching "Project Name" or "project name"
            # re.DOTALL: allows (.) to match newlines if needed, though we restrict slightly here
            match = re.search(pattern, full_text_search, re.IGNORECASE)
            if match:
                value = match.group(1).strip()
                # Remove common trailing punctuation
                if value.endswith('.'): value = value[:-1]
                extracted_data[key] = value
            else:
                extracted_data[key] = "Not Found"

        # --- 3. COST TABLE EXTRACTION ---
        # Look for the table containing "Description" and "Amount"
        for table in all_tables:
            flat_table = str(table).lower()
            if "description" in flat_table and "amount" in flat_table:
                cost_details = parse_cost_table(table)
                extracted_data.update(cost_details)

        # --- 4. VIOLATION DETECTION (For AI Risk Logic) ---
        # Scans the full text for specific keywords indicating rejection or risk
        extracted_data['potential_violations'] = []
        lower_text = full_text.lower()
        
        risk_keywords = {
            "proposal rejected": "Proposal explicitly rejected in document",
            "violation": "Regulatory violation detected",
            "deficit": "Resource deficit (e.g., parking) detected",
            "undersized": "Equipment undersized for capacity",
            "non-compliant": "Non-compliant with norms",
            "unsafe": "Structural safety concern detected"
        }

        for keyword, reason in risk_keywords.items():
            if keyword in lower_text:
                extracted_data['potential_violations'].append(reason)

    except Exception as e:
        extracted_data['error'] = str(e)

    return extracted_data

if __name__ == "__main__":
    # Standard boilerplate to receive file path from Node.js
    if len(sys.argv) > 1:
        pdf_file_path = sys.argv[1]
        data = extract_data(pdf_file_path)
        # Print JSON to stdout so Node.js can read it
        print(json.dumps(data))
    else:
        print(json.dumps({"error": "No file path provided"}))
        
