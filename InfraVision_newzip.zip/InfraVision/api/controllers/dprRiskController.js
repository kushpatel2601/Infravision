import axios from "axios";
import DPR from "../models/DPR.js";

/**
 * Call Python AI service & store result
 */
export const processDPR = async (req, res) => {
  try {
    const { pdfPath, userId } = req.body;

    const aiResponse = await axios.post("http://127.0.0.1:8001/analyze", {
      pdf_path: pdfPath,
    });

    const dpr = new DPR({
      userId,
      pdfPath,
      metrics: aiResponse.data.metrics,
      riskScore: aiResponse.data.risk_score,
      riskLevel: aiResponse.data.risk_level,
      explanation: aiResponse.data.explanation,
    });

    await dpr.save();

    res.json(dpr);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Fetch user's DPR history
 */
export const getUserDPRs = async (req, res) => {
  try {
    const { userId } = req.params;
    const dprs = await DPR.find({ userId }).sort({ createdAt: -1 });
    res.json(dprs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
