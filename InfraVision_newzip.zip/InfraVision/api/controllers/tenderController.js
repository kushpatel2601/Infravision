
import { PythonShell } from 'python-shell';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import Tender from '../models/Tender.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- 1. UPLOAD & EXTRACT FUNCTION ---
export const extractTenderData = async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  // Get User ID from Body (ensure your frontend sends 'userId')
  const userId = req.body.userId; 

  // Debug Log: Check if User ID is arriving
  console.log("Debug - Request Body:", req.body); 

  if (!userId) {
     if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
     return res.status(400).json({ error: 'User not authenticated: Missing userId' });
  }

  // Use absolute path for safety
  const filePath = path.resolve(req.file.path);

  const options = {
    mode: 'text',
    pythonPath: 'python', 
    pythonOptions: ['-u'],
    scriptPath: path.join(__dirname, '../python/'),
    args: [filePath],
  };

  console.log(`Debug - Starting Python Script on: ${filePath}`);

  PythonShell.run('ocr_engine.py', options)
    .then(async (messages) => {
      // --- DEBUG: Print exactly what Python sent back ---
      console.log('Debug - Python Output:', messages); 

      try {
        if (!messages || messages.length === 0) throw new Error("Python returned empty output");

        // Parse the JSON
        const resultJson = JSON.parse(messages.join(''));
        
        if (resultJson.error) throw new Error(resultJson.error);

        // Add userId and save
        const tenderData = { ...resultJson, userId: userId };

        const newTender = new Tender(tenderData);
        await newTender.save();

        // Cleanup file
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

        res.status(200).json({
          status: 'success',
          data: tenderData,
        });

      } catch (err) {
        console.error("Debug - Parsing Error:", err.message);
        // Cleanup file on error
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        res.status(500).json({ error: 'Processing failed', details: err.message });
      }
    })
    .catch((err) => {
      console.error("Debug - PythonShell Error:", err);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      res.status(500).json({ error: 'OCR Engine Failed', details: err.message });
    });
};

// --- 2. GET HISTORY FUNCTION ---
export const getUserTenders = async (req, res) => {
  try {
    const { userId } = req.params;
    if (!userId) return res.status(400).json({ error: 'User ID is required' });

    const tenders = await Tender.find({ userId }).sort({ createdAt: -1 });
    res.status(200).json({ status: 'success', data: tenders });
  } catch (error) {
    res.status(500).json({ error: 'Database fetch failed' });
  }
};


// ... existing getUserTenders code ...

// --- ADD THIS FUNCTION ---
export const getAllTenders = async (req, res) => {
  try {
    // 1. Fetch all records from MongoDB
    const tenders = await Tender.find().sort({ createdAt: -1 });

    // 2. Return the data
    res.status(200).json(tenders);
  } catch (error) {
    console.error("Error fetching all tenders:", error);
    res.status(500).json({ message: "Server Error fetching DPRs", error: error.message });
  }
};