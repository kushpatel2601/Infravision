import sys
import json
import pdfplumber
import re
import os

# --- YOUR EXISTING HELPER FUNCTIONS ---
def normalize_key(key):
    if key is None: return ""
    return re.sub(r'[^a-zA-Z0-9]', '', str(key)).lower()

def clean_value(text):
    if text is None: return ""
    return re.sub(r'\s+', ' ', str(text)).strip()

def deduplicate_text(text):
    text = clean_value(text)
    if not text: return ""
    mid_point = len(text) // 2
    for i in range(mid_point - 1, mid_point + 2):
        part1 = text[:i]
        part2 = text[i:]
        if len(part2) > 0 and part2.startswith(' '):
            if part1 == part2[1:]: return part1
        if part1 == part2: return part1
    return text

def extract_email_address(text):
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    matches = re.findall(email_pattern, text)
    return matches[0] if matches else ""

# --- YOUR FIELD MAPPING ---
FIELD_MAPPING = {
    "tenderreferencenumber": "tender_reference_number",
    "tenderid": "tender_id",
    "withdrawalallowed": "withdrawal_allowed",
    "tendertype": "tender_type",
    "formofcontract": "form_of_contract",
    "tendercategory": "tender_category",
    "noofcovers": "number_of_covers",
    "generaltechnicalevaluationallowed": "general_technical_evaluation",
    "itemwisetechnicalevaluationallowed": "itemwise_technical_evaluation",
    "paymentmode": "payment_mode",
    "ismulticurrencyallowedforboq": "multi_currency_allowed_for_boq",
    "allowtwostagebidding": "two_stage_bidding",
    "tenderfeein": "tender_fee",
    "feepayableto": "tender_fee_payable_to",
    "feepayableat": "tender_fee_payable_at",
    "tenderfeeexemptionallowed": "tender_fee_exemption",
    "emdamountin": "emd_amount",
    "emdexemptionallowed": "emd_exemption",
    "emdfeetype": "emd_fee_type",
    "emdpercentage": "emd_percentage",
    "emdpayableto": "emd_payable_to",
    "emdpayableat": "emd_payable_at",
    "tendervaluein": "tender_value",
    "productcategory": "product_category",
    "subcategory": "sub_category",
    "contracttype": "contract_type",
    "bidvaliditydays": "bid_validity_days",
    "periodofworkdays": "period_work_days",
    "location": "location",
    "pincode": "pincode",
    "prebidmeetingplace": "pre_bid_meeting_place",
    "prebidmeetingaddress": "pre_bid_meeting_address",
    "prebidmeetingdate": "pre_bid_meeting_date",
    "bidopeningplace": "bid_opening_place",
    "name": "authority_name",
    "address": "authority_address",
    "publishdate": "publish_date",
    "bidopeningdate": "bid_opening_date",
    "documentdownloadsalestartdate": "document_download_start",
    "documentdownloadsaleenddate": "document_download_end",
    "clarificationstartdate": "clarification_start",
    "clarificationenddate": "clarification_end",
    "bidsubmissionstartdate": "bid_submission_start",
    "bidsubmissionenddate": "bid_submission_end"
}

def extract_data(pdf_path):
    tender_data = {}
    try:
        with pdfplumber.open(pdf_path) as pdf:
            full_text_pages = []
            for page in pdf.pages:
                page_text = page.extract_text(x_tolerance=1, y_tolerance=1, layout=True)
                if page_text: full_text_pages.append(page_text)
            full_text = "\n".join(full_text_pages)
            full_text_normalized = re.sub(r'\s+', ' ', full_text)

            # 1. Email
            tender_data['authority_email'] = extract_email_address(full_text_normalized)

            # 2. Regex Extraction
            desc_stop_pattern = r'Pre Qualification|Independent External Monitor|Tender Value|Product Category|Sub\s*Category|Contract Type|Bid Validity|Period Of Work|Location|Pincode|Tender Fee|EMD Amount|Critical Dates|Details'
            
            data = ""
            match = re.search(rf'Work/Item\(s\)\.?\s*(.*?)\s*({desc_stop_pattern})', full_text_normalized, re.IGNORECASE | re.DOTALL)
            if match and match.group(1).strip(): data = match.group(1)
            
            if data:
                data = re.sub(r'Work/Item\(s\)\.?|Work Description|Title', '', data, flags=re.IGNORECASE).strip()
                cleaned_data = deduplicate_text(data)
                tender_data['title'] = cleaned_data
                tender_data['work_description'] = cleaned_data

            # 3. Table Extraction
            for page in pdf.pages:
                tables = page.extract_tables()
                for table in tables:
                    for row in table:
                        cleaned_row = [clean_value(cell) for cell in row if clean_value(cell)]
                        for i in range(len(cleaned_row)):
                            item = cleaned_row[i]
                            key_norm = normalize_key(item)
                            if key_norm in FIELD_MAPPING:
                                if i + 1 < len(cleaned_row):
                                    value = cleaned_row[i+1]
                                    if normalize_key(value) not in FIELD_MAPPING:
                                        csv_column_name = FIELD_MAPPING[key_norm]
                                        tender_data[csv_column_name] = value

    except Exception as e:
        tender_data['error'] = str(e)
    
    return tender_data

if __name__ == "__main__":
    # Receive file path from Node.js arguments
    if len(sys.argv) > 1:
        pdf_file_path = sys.argv[1]
        data = extract_data(pdf_file_path)
        # Print JSON to stdout so Node.js can read it
        print(json.dumps(data))
    else:
        print(json.dumps({"error": "No file path provided"}))