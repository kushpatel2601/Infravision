import PyPDF2
import re
import json
import os
import uuid 

# Path where uploaded PDF will be stored temporarily
upload_folder = "uploads"
os.makedirs(upload_folder, exist_ok=True)

# File paths
uploaded_pdf_path = os.path.join(upload_folder, "uploaded.pdf")
json_file_path = "output.json"

# Load existing data if file exists
if os.path.exists(json_file_path):
    with open(json_file_path, "r") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            data = []
else:
    data = []

# ---------- Process Uploaded PDF ----------
if os.path.exists(uploaded_pdf_path):
    print(f"Processing uploaded file: {uploaded_pdf_path}")

    with open(uploaded_pdf_path, "rb") as pdf_file:
        reader = PyPDF2.PdfReader(pdf_file)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"

    # ---------------- Extract Data ----------------
    Organisation_Chain_match = re.search(r'Organisation Chain[:\s\-]*([\w\s&,-]+)', text, re.IGNORECASE)
    tender_fee_match = re.search(r'Tender Fee in ₹[:\s\-]*([\d,\.]+)', text, re.IGNORECASE)
    emd_amount_match = re.search(r'EMD Amount in ₹[:\s\-]*([\d,\.]+)', text, re.IGNORECASE)
    tender_value_match = re.search(r'Tender Value in ₹[:\s\-]*([\d,\.]+)', text, re.IGNORECASE)

    Organisation_Chain = Organisation_Chain_match.group(1) if Organisation_Chain_match else None
    tender_fee = tender_fee_match.group(1).replace(',', '') if tender_fee_match else None
    emd_amount = emd_amount_match.group(1).replace(',', '') if emd_amount_match else None
    tender_value = tender_value_match.group(1).replace(',', '') if tender_value_match else None

    # ---------------- Prepare Data with Unique ID ----------------
    entry = {
        "id": str(uuid.uuid4()),  # Generate unique ID
        "filename": os.path.basename(uploaded_pdf_path),
        "Organisation Chain": Organisation_Chain,
        "Tender Fee": tender_fee,
        "EMD Amount": emd_amount,
        "Tender Value": tender_value
    }

    # Append new entry
    data.append(entry)

    # Save to JSON
    with open(json_file_path, "w") as f:
        json.dump(data, f, indent=4)

    print(f"✅ Data from uploaded PDF saved to {json_file_path}")
else:
    print("❌ No uploaded file found in 'uploads/' folder.")
