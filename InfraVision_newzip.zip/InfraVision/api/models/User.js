import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    type: {
        type: String,
        enum: ['governor', 'investor', 'banker','user'], // Allowed user types
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Export the model using ES module syntax
const User = mongoose.model('User', userSchema);

export default User;
