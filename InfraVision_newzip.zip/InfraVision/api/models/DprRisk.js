const mongoose = require("mongoose");

const DprRiskSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  fileName: String,
  filePath: String,
  status: {
    type: String,
    enum: ["UPLOADED", "PROCESSING", "COMPLETED", "FAILED"],
    default: "UPLOADED",
  },
  metrics: Object,
  riskScore: Number,
  riskLevel: String,
  explanation: String,
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("DprRisk", DprRiskSchema);
