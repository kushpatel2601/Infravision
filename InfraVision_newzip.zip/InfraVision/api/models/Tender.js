import mongoose from 'mongoose';

const TenderSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, // changed from String
    ref: 'User', // IMPORTANT: This must match the name of your User model exactly
    required: true, 
    index: true 
  },
  
}, { 
  strict: false, // Keeps your dynamic OCR fields working
  timestamps: true // Adds createdAt and updatedAt automatically
});

export default mongoose.model('Tender', TenderSchema);