import mongoose from "mongoose";

const dprSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    fileName: {
      type: String,
      required: true,
    },

    pages: Number,

    metrics: {
      land_pages: Number,
      environment_pages: Number,
      money_mentions: Number,
      legal_mentions: Number,
    },

    risk_score: {
      type: Number,
      required: true,
    },

    risk_level: {
      type: String,
      enum: ["LOW", "MEDIUM", "HIGH"],
      required: true,
    },

    explanation: String,
  },
  { timestamps: true }
);

const DPR = mongoose.model("DPR", dprSchema);

export default DPR;
