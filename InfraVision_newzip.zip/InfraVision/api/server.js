import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";

import authRoutes from "./routes/authRoutes.js";
import tenderRoutes from "./routes/tenderRoutes.js";
import dprRiskRoutes from "./routes/dprRiskRoutes.js";

dotenv.config();

const app = express();
app.get("/", (req, res) => {
  res.send("InfraVision Backend is running 🚀");
});

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/tenders", tenderRoutes);
app.use("/api/dpr", dprRiskRoutes);

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(5000, () =>
      console.log("🚀 Backend running on http://localhost:5000")
    );
  })
  .catch((err) => console.error(err));
