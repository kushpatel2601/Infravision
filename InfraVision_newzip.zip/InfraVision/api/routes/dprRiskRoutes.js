import express from "express";
import { processDPR, getUserDPRs } from "../controllers/dprRiskController.js";

const router = express.Router();

/**
 * Upload + Analyze DPR
 */
router.post("/analyze", processDPR);

/**
 * Get DPRs uploaded by a user
 */
router.get("/user/:userId", getUserDPRs);

export default router;
