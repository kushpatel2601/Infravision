import express from "express";
import Tender from "../models/Tender.js";

const router = express.Router();

/**
 * CREATE TENDER
 */
router.post("/", async (req, res) => {
  try {
    const tender = new Tender(req.body);
    await tender.save();
    res.status(201).json(tender);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET ALL TENDERS
 */
router.get("/", async (req, res) => {
  try {
    const tenders = await Tender.find().sort({ createdAt: -1 });
    res.json(tenders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET TENDER BY ID
 */
router.get("/:id", async (req, res) => {
  try {
    const tender = await Tender.findById(req.params.id);
    if (!tender) {
      return res.status(404).json({ message: "Tender not found" });
    }
    res.json(tender);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
