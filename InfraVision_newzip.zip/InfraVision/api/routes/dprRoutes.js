import express from "express";
import multer from "multer";
import path from "path";
// Note: Ensure the controller is also using ESM or imported correctly.
// If using the previous controller code, import the specific function:
import { processDPR, getUserDPRs } from "../controllers/dprRiskController.js";

const router = express.Router();

// --- 1. MULTER CONFIGURATION (Handles File Uploads) ---
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Files will be saved in the 'uploads' folder in your root directory
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    // Naming the file: Timestamp + Original Name (prevents overwriting)
    cb(null, Date.now() + "-" + file.originalname);
  },
});

// Create the upload middleware
const upload = multer({ storage: storage });

// --- 2. DEFINE THE ROUTE ---
// Endpoint: POST http://localhost:5000/api/dpr/analyze
router.post("/analyze", upload.single("file"), processDPR);

// GET: Fetch History (Add this line)
router.get("/history/:userId", getUserDPRs);

export default router;
