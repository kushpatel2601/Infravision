import { Route, Routes, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Header from './components/Header';
import Footer from './components/Footer';
import Login from './pages/Login';
import Register from './pages/Register';
import InvestorDashboard from './pages/invester/InvesterDashboard';
import GovernorDashboard from './pages/governor/GovernorDashboard';
import UserDashboard from './pages/user/Upload';
import BankerDashboard from './pages/banker/BankerDashboard';
import AnalysisPage from './pages/user/AnalysisPage';
import MyTenders from './pages/user/MyTenders';
import Alldprs from './pages/governor/Alldprs'
import Profile from './pages/Profile';
import Settings from './pages/Setting';

// ✅ Protected Route Component (JSX)
const ProtectedRoute = ({ children, role }) => {
  const token = sessionStorage.getItem('token') || localStorage.getItem('token');
  const userType = sessionStorage.getItem('userType') || localStorage.getItem('userType');

  // If no token, redirect to login
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // If role doesn't match, redirect to home
  if (role && userType !== role) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='/profile' element={<Profile />} />
        <Route path='/settings' element={<Settings />} />

        {/* ✅ Protected Role Based Routes */}
        <Route
          path='/governor'
          element={
            <ProtectedRoute role="governor">
              <GovernorDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path='/governor/dprs'
          element={
            <ProtectedRoute role="governor">
              <Alldprs />
            </ProtectedRoute>
          }
        />

        <Route
          path='/investor'
          element={
            <ProtectedRoute role="investor">
              <InvestorDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path='/banker'
          element={
            <ProtectedRoute role="banker">
              <BankerDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path='/user/upload'
          element={
            <ProtectedRoute role="user">
              <UserDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path='/user/analysis/:id'
          element={
            <ProtectedRoute role="user">
             <AnalysisPage />
             </ProtectedRoute>}
            // <ProtectedRoute role="user">
            // {/* </ProtectedRoute> */}
        />

        <Route
          path='/user/dashboard'
          element={
            <ProtectedRoute role="user">
              <MyTenders />
            </ProtectedRoute>
          }
        />

      </Routes>
      <Footer />
    </>
  );
}

export default App;