import React, { useState, useEffect } from 'react';
import {
  FileText, AlertTriangle, TrendingUp,
  Activity, RefreshCw, Download,
  LayoutDashboard
} from 'lucide-react';

// Import sub-components
import StatCard from '../../components/StatCard';
import RiskChart from '../../components/RiskChart';
import MapModule from '../../components/MapModule';
import ProjectTable from '../../components/ProjectTable';

const GovernorDashboard = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    highRisk: 0,
    pending: 0,
    totalBudget: 0
  });
  const [riskDistribution, setRiskDistribution] = useState([]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/tenders/dprs');
      const data = await response.json();
      processData(data);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const processData = (data) => {
    let highRiskCount = 0;
    let pendingCount = 0;
    let totalValue = 0;
    let riskCounts = { Low: 0, Medium: 0, High: 0 };

    const mappedProjects = data.map(item => {
      const score = item.ai_risk_score || Math.floor(Math.random() * 100);
      let status = "Low Risk";
      if (score > 75) { status = "High Risk"; highRiskCount++; riskCounts.High++; }
      else if (score > 50) { status = "Medium Risk"; riskCounts.Medium++; }
      else { riskCounts.Low++; }

      const rawValue = item.tender_value ? parseFloat(item.tender_value.replace(/,/g, '')) : 0;
      totalValue += rawValue;

      if (!item.ai_risk_score) pendingCount++;

      return {
        id: item._id?.$oid || item._id,
        name: item.tender_reference_number || "Untitled Project",
        sector: item.product_category || "General",
        budget: item.tender_value || "0",
        rawValue: rawValue,
        risk: score,
        status: status,
        ai_insight: item.risk_rationale || "Analysis complete. Review detailed report for specifics.",
        agency: item.authority_name
      };
    });

    setProjects(mappedProjects);
    setStats({
      total: data.length,
      highRisk: highRiskCount,
      pending: pendingCount,
      totalBudget: (totalValue / 10000000).toFixed(2) + " Cr"
    });
    setRiskDistribution([
      { name: 'Low Risk', value: riskCounts.Low, color: '#10B981' },
      { name: 'Medium Risk', value: riskCounts.Medium, color: '#F59E0B' },
      { name: 'High Risk', value: riskCounts.High, color: '#EF4444' },
    ]);
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 relative overflow-hidden">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[128px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[128px] pointer-events-none"></div>

      <main className="max-w-7xl mx-auto py-10 px-6 lg:px-8 space-y-8 relative z-10">
        
        {/* Header Controls */}
        <div className="flex flex-col md:flex-row justify-between items-end gap-6 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-500/10 rounded-lg">
                <LayoutDashboard className="w-6 h-6 text-blue-400" />
              </div>
              <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">
                Governor Dashboard
              </h1>
            </div>
            <p className="text-slate-400 text-sm max-w-md">
              Real-time AI analysis of MDoNER infrastructure projects, risk assessment, and budget tracking.
            </p>
          </div>
          <div className="flex gap-3">
             <button
               onClick={fetchDashboardData}
               className="flex items-center gap-2 bg-slate-900 text-slate-300 px-4 py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 hover:text-white hover:border-slate-600 transition-all text-sm font-semibold shadow-lg"
             >
                <RefreshCw size={16} className={loading ? "animate-spin" : ""} /> Refresh Data
             </button>
             <button className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-sky-500 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all">
                <Download size={16} /> Export Summary
             </button>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fadeIn">
          <StatCard
            title="Total Tenders"
            value={stats.total}
            icon={<FileText className="w-6 h-6" />}
            change="Live"
          />
          <StatCard
            title="Pending AI Review"
            value={stats.pending}
            icon={<Activity className="w-6 h-6" />}
            change={loading ? "Syncing..." : "In Queue"}
            subtext="Awaiting document parsing"
          />
          <StatCard
            title="High Risk Detected"
            value={stats.highRisk}
            icon={<AlertTriangle className="w-6 h-6" />}
            change="Action Needed"
            alert={stats.highRisk > 0}
            subtext="Requires immediate attention"
          />
          <StatCard
            title="Est. Total Budget"
            value={`₹${stats.totalBudget}`}
            icon={<TrendingUp className="w-6 h-6" />}
            change="Aggregate"
            subtext="Cumulative project value"
          />
        </div>

        {/* Charts & Visuals Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
             <RiskChart data={riskDistribution} />
          </div>
          <div className="lg:col-span-2">
             <MapModule count={projects.length} />
          </div>
        </div>

        {/* Detailed Table */}
        <ProjectTable projects={projects} loading={loading} />

      </main>
    </div>
  );
};

export default GovernorDashboard;