// import React, { useState, useEffect } from 'react';
// import { 
//   Search, 
//   Filter, 
//   Download, 
//   Eye, 
//   MoreVertical, 
//   FileText, 
//   MapPin, 
//   Calendar,
//   Loader2,
//   RefreshCw,
//   AlertTriangle
// } from 'lucide-react';

// const Alldprs = () => {
//   // --- State Management ---
//   const [dprData, setDprData] = useState([]); // Stores data from MongoDB
//   const [loading, setLoading] = useState(true); // Loading state
//   const [error, setError] = useState(null); // Error state
//   const [searchTerm, setSearchTerm] = useState("");
//   const [filterRisk, setFilterRisk] = useState("All");

//   // --- 1. Fetch Data from Backend ---
//   const fetchDPRs = async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       // REPLACE with your actual API Endpoint
//       const response = await fetch('http://localhost:5000/api/tenders/dprs'); 
      
//       if (!response.ok) {
//         throw new Error('Failed to fetch data from server');
//       }

//       const rawData = await response.json();

//       // --- 2. Data Mapping (MongoDB -> UI) ---
//       // This maps your database field names to the names this UI component expects.
//       const mappedData = rawData.map(item => ({
//         id: item.dpr_id || item._id,       // Use 'dpr_id' or fallback to MongoDB '_id'
//         title: item.project_name,          // Map 'project_name' to 'title'
//         agency: item.agency_name,          // Map 'agency_name' to 'agency'
//         state: item.state,
//         sector: item.sector,
//         cost: item.estimated_cost,         // e.g., "₹180 Cr"
//         date: new Date(item.submission_date).toISOString().split('T')[0], // Format Date
//         riskScore: item.ai_risk_score || 0, // Default to 0 if missing
//         status: item.risk_status || "Pending"
//       }));

//       setDprData(mappedData);
//     } catch (err) {
//       console.error("Error fetching DPRs:", err);
//       setError("Could not load project data. Please check your connection.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Run fetch on component mount
//   useEffect(() => {
//     fetchDPRs();
//   }, []);

//   // --- Filtering Logic ---
//   const filteredData = dprData.filter((item) => {
//     const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
//                           item.id.toString().toLowerCase().includes(searchTerm.toLowerCase());
//     const matchesRisk = filterRisk === "All" || item.status === filterRisk;
//     return matchesSearch && matchesRisk;
//   });

//   return (
//     <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-8 font-sans">
      
//       {/* --- Page Header --- */}
//       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
//         <div>
//           <h1 className="text-3xl font-bold text-white tracking-tight">Project Registry</h1>
//           <p className="text-slate-400 mt-1 text-sm">Real-time data from MDoNER Database.</p>
//         </div>
        
//         <div className="flex gap-3">
//           <button onClick={fetchDPRs} className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-800 hover:text-white transition-all text-sm font-medium">
//             <RefreshCw size={16} className={loading ? "animate-spin" : ""} /> Refresh
//           </button>
//           <button className="flex items-center gap-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg shadow-lg shadow-sky-900/20 transition-all text-sm font-bold">
//             + New Upload
//           </button>
//         </div>
//       </div>

//       {/* --- Filters & Search Bar --- */}
//       <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl mb-6 backdrop-blur-sm">
//         <div className="flex flex-col md:flex-row gap-4">
//           <div className="relative flex-1">
//             <Search className="absolute left-3 top-2.5 text-slate-500" size={18} />
//             <input 
//               type="text" 
//               placeholder="Search by Project Name or ID..." 
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//               className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-sky-500 transition-all"
//             />
//           </div>
//           <div className="relative min-w-[180px]">
//             <Filter className="absolute left-3 top-2.5 text-slate-500" size={18} />
//             <select 
//               value={filterRisk}
//               onChange={(e) => setFilterRisk(e.target.value)}
//               className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:ring-1 focus:ring-sky-500 appearance-none cursor-pointer"
//             >
//               <option value="All">All Risk Levels</option>
//               <option value="High Risk">High Risk</option>
//               <option value="Medium Risk">Medium Risk</option>
//               <option value="Low Risk">Low Risk</option>
//             </select>
//           </div>
//         </div>
//       </div>

//       {/* --- Data Table Content --- */}
//       <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl shadow-black/40">
        
//         {/* State: Loading */}
//         {loading && (
//           <div className="p-12 flex flex-col items-center justify-center text-slate-400">
//             <Loader2 size={48} className="animate-spin text-sky-500 mb-4" />
//             <p>Fetching projects from database...</p>
//           </div>
//         )}

//         {/* State: Error */}
//         {!loading && error && (
//           <div className="p-12 flex flex-col items-center justify-center text-red-400">
//             <AlertTriangle size={48} className="mb-4" />
//             <p className="text-lg font-semibold">Connection Error</p>
//             <p className="text-sm opacity-80">{error}</p>
//             <button onClick={fetchDPRs} className="mt-4 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded hover:bg-red-500/20 text-red-300 text-sm">Try Again</button>
//           </div>
//         )}

//         {/* State: Success (Data Table) */}
//         {!loading && !error && (
//           <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-slate-950/80 text-slate-400 text-xs uppercase tracking-wider">
//                 <tr>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800">DPR ID</th>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800">Project Details</th>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800">Agency & State</th>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800">Est. Cost</th>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800">AI Risk Analysis</th>
//                   <th className="px-6 py-4 font-semibold border-b border-slate-800 text-right">Actions</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-slate-800 text-sm">
//                 {filteredData.length > 0 ? (
//                   filteredData.map((project) => (
//                     <tr key={project.id} className="hover:bg-slate-800/50 transition-colors group">
//                       <td className="px-6 py-4 text-slate-500 font-mono">{project.id}</td>
//                       <td className="px-6 py-4">
//                         <div className="flex items-start gap-3">
//                           <div className="p-2 rounded bg-slate-800 text-sky-500 mt-1">
//                             <FileText size={16} />
//                           </div>
//                           <div>
//                             <p className="text-slate-200 font-medium group-hover:text-sky-400 transition-colors">{project.title}</p>
//                             <div className="flex items-center gap-2 text-slate-500 text-xs mt-1">
//                               <Calendar size={12} /> {project.date}
//                             </div>
//                           </div>
//                         </div>
//                       </td>
//                       <td className="px-6 py-4">
//                         <p className="text-slate-300">{project.agency}</p>
//                         <div className="flex items-center gap-1 text-slate-500 text-xs mt-1">
//                           <MapPin size={12} /> {project.state}
//                         </div>
//                       </td>
//                       <td className="px-6 py-4 font-mono text-slate-300">{project.cost}</td>
//                       <td className="px-6 py-4">
//                         <RiskBadge score={project.riskScore} label={project.status} />
//                       </td>
//                       <td className="px-6 py-4 text-right">
//                         <button className="p-2 text-slate-400 hover:text-sky-400 hover:bg-slate-800 rounded-full transition-all">
//                           <Eye size={18} />
//                         </button>
//                       </td>
//                     </tr>
//                   ))
//                 ) : (
//                   <tr>
//                     <td colSpan="6" className="px-6 py-12 text-center text-slate-500">
//                       No matching projects found.
//                     </td>
//                   </tr>
//                 )}
//               </tbody>
//             </table>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// // --- Helper: Risk Badge (Same as before) ---
// const RiskBadge = ({ score, label }) => {
//   let styles = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
//   if (score > 75) {
//     styles = "bg-red-500/10 text-red-400 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.1)]";
//   } else if (score > 50) {
//     styles = "bg-yellow-500/10 text-yellow-400 border-yellow-500/20";
//   }
//   return (
//     <div className="flex items-center gap-3">
//       <div className="w-full bg-slate-800 rounded-full h-1.5 w-16 overflow-hidden">
//         <div className={`h-full rounded-full ${score > 75 ? 'bg-red-500' : score > 50 ? 'bg-yellow-500' : 'bg-emerald-500'}`} style={{ width: `${score}%` }}></div>
//       </div>
//       <span className={`px-2 py-0.5 rounded text-xs font-medium border ${styles} whitespace-nowrap`}>
//         {score}% {label}
//       </span>
//     </div>
//   );
// };

// export default Alldprs;



import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Eye, 
  FileText, 
  MapPin, 
  Calendar,
  Loader2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';

const Alldprs = () => {
  // --- State Management ---
  const [dprData, setDprData] = useState([]); 
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null); 
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRisk, setFilterRisk] = useState("All");

  // --- 1. Fetch Data from Backend ---
  const fetchDPRs = async () => {
    setLoading(true);
    setError(null);
    try {
      // REPLACE with your actual API Endpoint
      const response = await fetch('http://localhost:5000/api/tenders/dprs'); 
      
      if (!response.ok) {
        throw new Error('Failed to fetch data from server');
      }

      const rawData = await response.json();

      // --- 2. Data Mapping (MongoDB -> UI) ---
      const mappedData = rawData.map(item => {
        // Helper to safely get date string whether it's "2025-..." or { $date: "2025..." }
        const rawDate = item.createdAt?.$date || item.createdAt || item.publish_date;
        let formattedDate = "N/A";
        
        try {
            if (rawDate) {
                formattedDate = new Date(rawDate).toISOString().split('T')[0];
            }
        } catch (e) {
            formattedDate = "Invalid Date";
        }

        // Mocking Risk Score if it doesn't exist in your JSON yet
        // (Your provided JSON didn't have risk_score, so I added a default/random for UI demo)
        const mockScore = item.ai_risk_score || Math.floor(Math.random() * 100); 
        let mockStatus = "Low Risk";
        if (mockScore > 75) mockStatus = "High Risk";
        else if (mockScore > 50) mockStatus = "Medium Risk";

        return {
          // Use tender_id or fallback to MongoDB _id (handling $oid if present)
          id: item.tender_id || item._id?.$oid || item._id, 
          
          // Map 'tender_reference_number' to 'title'
          title: item.tender_reference_number || "Untitled Tender", 
          
          // Map 'authority_name' to 'agency'
          agency: item.authority_name || "Unknown Authority", 
          
          // Map 'location' to 'state'
          state: item.location || "India",
          
          // Map 'product_category' to 'sector'
          sector: item.product_category || "General",
          
          // Map 'tender_value' to 'cost'
          cost: item.tender_value ? `₹${item.tender_value}` : "₹0", 
          
          date: formattedDate,
          riskScore: mockScore,
          status: item.risk_status || mockStatus
        };
      });

      setDprData(mappedData);
    } catch (err) {
      console.error("Error fetching DPRs:", err);
      setError("Could not load project data. Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  // Run fetch on component mount
  useEffect(() => {
    fetchDPRs();
  }, []);

  // --- Filtering Logic ---
  const filteredData = dprData.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.id.toString().toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = filterRisk === "All" || item.status === filterRisk;
    return matchesSearch && matchesRisk;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-8 font-sans">
      
      {/* --- Page Header --- */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Project Registry</h1>
          <p className="text-slate-400 mt-1 text-sm">Real-time data from MDoNER Database.</p>
        </div>
        
        <div className="flex gap-3">
          <button onClick={fetchDPRs} className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-800 hover:text-white transition-all text-sm font-medium">
            <RefreshCw size={16} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg shadow-lg shadow-sky-900/20 transition-all text-sm font-bold">
            + New Upload
          </button>
        </div>
      </div>

      {/* --- Filters & Search Bar --- */}
      <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl mb-6 backdrop-blur-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 text-slate-500" size={18} />
            <input 
              type="text" 
              placeholder="Search by Reference No or ID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-sky-500 transition-all"
            />
          </div>
          <div className="relative min-w-[180px]">
            <Filter className="absolute left-3 top-2.5 text-slate-500" size={18} />
            <select 
              value={filterRisk}
              onChange={(e) => setFilterRisk(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:ring-1 focus:ring-sky-500 appearance-none cursor-pointer"
            >
              <option value="All">All Risk Levels</option>
              <option value="High Risk">High Risk</option>
              <option value="Medium Risk">Medium Risk</option>
              <option value="Low Risk">Low Risk</option>
            </select>
          </div>
        </div>
      </div>

      {/* --- Data Table Content --- */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl shadow-black/40">
        
        {/* State: Loading */}
        {loading && (
          <div className="p-12 flex flex-col items-center justify-center text-slate-400">
            <Loader2 size={48} className="animate-spin text-sky-500 mb-4" />
            <p>Fetching projects from database...</p>
          </div>
        )}

        {/* State: Error */}
        {!loading && error && (
          <div className="p-12 flex flex-col items-center justify-center text-red-400">
            <AlertTriangle size={48} className="mb-4" />
            <p className="text-lg font-semibold">Connection Error</p>
            <p className="text-sm opacity-80">{error}</p>
            <button onClick={fetchDPRs} className="mt-4 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded hover:bg-red-500/20 text-red-300 text-sm">Try Again</button>
          </div>
        )}

        {/* State: Success (Data Table) */}
        {!loading && !error && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-950/80 text-slate-400 text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800">Tender ID</th>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800">Reference Details</th>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800">Authority & Location</th>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800">Tender Value</th>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800">AI Risk Analysis</th>
                  <th className="px-6 py-4 font-semibold border-b border-slate-800 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-sm">
                {filteredData.length > 0 ? (
                  filteredData.map((project) => (
                    <tr key={project.id} className="hover:bg-slate-800/50 transition-colors group">
                      <td className="px-6 py-4 text-slate-500 font-mono">{project.id}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-start gap-3">
                          <div className="p-2 rounded bg-slate-800 text-sky-500 mt-1">
                            <FileText size={16} />
                          </div>
                          <div>
                            <p className="text-slate-200 font-medium group-hover:text-sky-400 transition-colors">{project.title}</p>
                            <div className="flex items-center gap-2 text-slate-500 text-xs mt-1">
                              <Calendar size={12} /> {project.date}
                            </div>
                            <div className="text-xs text-slate-500 mt-0.5">
                                {project.sector}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-slate-300">{project.agency}</p>
                        <div className="flex items-center gap-1 text-slate-500 text-xs mt-1">
                          <MapPin size={12} /> {project.state}
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-300">{project.cost}</td>
                      <td className="px-6 py-4">
                        <RiskBadge score={project.riskScore} label={project.status} />
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button className="p-2 text-slate-400 hover:text-sky-400 hover:bg-slate-800 rounded-full transition-all">
                          <Eye size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">
                      No matching projects found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// --- Helper: Risk Badge ---
const RiskBadge = ({ score, label }) => {
  let styles = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
  if (score > 75) {
    styles = "bg-red-500/10 text-red-400 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.1)]";
  } else if (score > 50) {
    styles = "bg-yellow-500/10 text-yellow-400 border-yellow-500/20";
  }
  return (
    <div className="flex items-center gap-3">
      <div className="w-full bg-slate-800 rounded-full h-1.5 w-16 overflow-hidden">
        <div className={`h-full rounded-full ${score > 75 ? 'bg-red-500' : score > 50 ? 'bg-yellow-500' : 'bg-emerald-500'}`} style={{ width: `${score}%` }}></div>
      </div>
      <span className={`px-2 py-0.5 rounded text-xs font-medium border ${styles} whitespace-nowrap`}>
        {score}% {label}
      </span>
    </div>
  );
};

export default Alldprs;