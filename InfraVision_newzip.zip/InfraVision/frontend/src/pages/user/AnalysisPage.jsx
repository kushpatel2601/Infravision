// import { useLocation, useNavigate } from "react-router-dom";
// import { useEffect, useState } from "react";

// const AnalysisPage = () => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const { tenderData } = location.state || {}; // Retrieve passed data

//   const [riskScore, setRiskScore] = useState(0);
//   const [status, setStatus] = useState("Analyzing...");

//   useEffect(() => {
//     if (!tenderData) {
//       navigate('/user/dashboard'); // Go back if no data
//       return;
//     }

//     // SIMULATE ANALYSIS LOGIC (Replace with real AI backend logic later)
//     // Example rule: If budget is missing or description is short -> High Risk
//     setTimeout(() => {
//         let score = 15; // Base risk
        
//         // Logic: Check for budget
//         if (!tenderData.tender_value || tenderData.tender_value === 'NA') {
//             score += 40; // High risk if budget is hidden
//         }

//         // Logic: Check EMD
//         if (!tenderData.emd_amount || tenderData.emd_amount === 'NA') {
//             score += 20;
//         }

//         setRiskScore(score);
//         setStatus("Complete");
//     }, 2000);

//   }, [tenderData, navigate]);

//   if (!tenderData) return null;

//   return (
//     <div className="min-h-screen bg-[#F1F6F9] p-10">
//       <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        
//         {/* Header */}
//         <div className="bg-[#212A3E] p-6 text-white">
//           <h1 className="text-2xl font-bold">Tender Risk Analysis</h1>
//           <p className="text-[#9BA4B5] text-sm">AI-Driven Assessment for: {tenderData.title || "Untitled Project"}</p>
//         </div>

//         <div className="p-8">
//             {/* Status Loader */}
//             {status === "Analyzing..." ? (
//                 <div className="text-center py-10">
//                     <div className="animate-spin w-12 h-12 border-4 border-[#394867] border-t-transparent rounded-full mx-auto mb-4"></div>
//                     <p className="text-lg font-semibold text-[#394867]">Running Financial checks...</p>
//                 </div>
//             ) : (
//                 <div className="space-y-8 animate-fade-in">
                    
//                     {/* Risk Score Card */}
//                     <div className="flex items-center justify-between bg-gray-50 p-6 rounded-xl border border-gray-200">
//                         <div>
//                             <h3 className="text-gray-500 font-bold uppercase text-xs">Predicted Risk Score</h3>
//                             <p className={`text-4xl font-extrabold ${riskScore > 50 ? 'text-red-600' : 'text-green-600'}`}>
//                                 {riskScore}/100
//                             </p>
//                         </div>
//                         <div className="text-right">
//                             <h3 className="text-gray-500 font-bold uppercase text-xs">Verdict</h3>
//                             <span className={`px-4 py-1 rounded-full text-white font-bold text-sm ${riskScore > 50 ? 'bg-red-500' : 'bg-green-500'}`}>
//                                 {riskScore > 50 ? "HIGH RISK" : "SAFE TO BID"}
//                             </span>
//                         </div>
//                     </div>

//                     {/* Analysis Details */}
//                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                         <div className="p-5 border rounded-lg hover:shadow-md transition">
//                             <h4 className="font-bold text-[#212A3E] mb-2">💰 Budget Analysis</h4>
//                             <p className="text-sm text-gray-600">
//                                 {tenderData.tender_value && tenderData.tender_value !== 'NA' 
//                                     ? `Budget defined at ${tenderData.tender_value}. Within expected range.` 
//                                     : "⚠️ Budget is not clearly defined. This creates cost overrun risks."}
//                             </p>
//                         </div>
//                         <div className="p-5 border rounded-lg hover:shadow-md transition">
//                             <h4 className="font-bold text-[#212A3E] mb-2">📅 Timeline Check</h4>
//                             <p className="text-sm text-gray-600">
//                                 {tenderData.bid_submission_end 
//                                     ? `Submission deadline is ${tenderData.bid_submission_end}.` 
//                                     : "Critical dates missing. Timeline risk is high."}
//                             </p>
//                         </div>
//                     </div>

//                     <button onClick={() => navigate('/user/dashboard')} className="text-[#394867] font-semibold underline mt-4">
//                         ← Back to Dashboard
//                     </button>
//                 </div>
//             )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AnalysisPage;





// import { useLocation, useNavigate } from "react-router-dom";
// import { useEffect, useState } from "react";
// import { 
//   ArrowLeft, 
//   AlertTriangle, 
//   CheckCircle, 
//   DollarSign, 
//   Calendar, 
//   FileText, 
//   Activity,
//   Loader2
// } from "lucide-react";

// const AnalysisPage = () => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const { tenderData } = location.state || {}; 

//   const [riskScore, setRiskScore] = useState(0);
//   const [status, setStatus] = useState("Analyzing...");

//   useEffect(() => {
//     if (!tenderData) {
//       navigate('/user/dashboard'); 
//       return;
//     }

//     const timer = setTimeout(() => {
//         let score = 15; 
        
//         if (!tenderData.tender_value || tenderData.tender_value === 'NA') {
//             score += 40; 
//         }

//         if (!tenderData.emd_amount || tenderData.emd_amount === 'NA') {
//             score += 20;
//         }

//         setRiskScore(score);
//         setStatus("Complete");
//     }, 2000);

//     return () => clearTimeout(timer);

//   }, [tenderData, navigate]);

//   if (!tenderData) return null;

//   return (
//     <div className="min-h-screen bg-slate-950 relative overflow-hidden p-6 md:p-10 font-sans text-slate-100">
      
//       {/* Background Ambience */}
//       <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
//       <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[128px] pointer-events-none"></div>
//       <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-600/10 rounded-full blur-[128px] pointer-events-none"></div>

//       <div className="max-w-4xl mx-auto relative z-10">
        
//         {/* Back Button */}
//         <button 
//           onClick={() => navigate('/user/dashboard')} 
//           className="mb-6 flex items-center gap-2 text-slate-400 hover:text-sky-400 transition-colors group"
//         >
//           <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
//           Back to Dashboard
//         </button>

//         <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-fadeIn">
        
//           {/* Header */}
//           <div className="bg-slate-900/80 border-b border-slate-800 p-8">
//             <div className="flex items-center gap-3 mb-2">
//               <Activity className="text-sky-400 w-6 h-6" />
//               <h1 className="text-2xl font-bold text-slate-100">Tender Risk Analysis</h1>
//             </div>
//             <p className="text-slate-400 text-sm pl-9">
//               AI-Driven Assessment for: <span className="text-slate-200 font-semibold">{tenderData.title || "Untitled Project"}</span>
//             </p>
//           </div>

//           <div className="p-8">
//             {/* Status Loader */}
//             {status === "Analyzing..." ? (
//               <div className="text-center py-20 flex flex-col items-center">
//                 <Loader2 className="w-12 h-12 text-sky-500 animate-spin mb-6" />
//                 <h3 className="text-xl font-bold text-slate-200 mb-2">Analyzing Tender Document</h3>
//                 <p className="text-slate-500">Running financial checks, compliance verification, and risk modeling...</p>
//               </div>
//             ) : (
//               <div className="space-y-8 animate-fadeIn">
                  
//                 {/* Risk Score Card */}
//                 <div className="flex flex-col md:flex-row items-center justify-between bg-slate-950/50 p-8 rounded-xl border border-slate-800 gap-6">
//                   <div>
//                     <h3 className="text-slate-500 font-bold uppercase text-xs tracking-wider mb-2">Predicted Risk Score</h3>
//                     <div className="flex items-baseline gap-2">
//                       {/* FIX 1: Added backticks around className string */}
//                       <span className={`text-5xl font-extrabold ${riskScore > 50 ? 'text-rose-500' : 'text-emerald-500'}`}>
//                         {riskScore}
//                       </span>
//                       <span className="text-slate-600 text-xl font-medium">/ 100</span>
//                     </div>
//                   </div>
                  
//                   <div className="h-12 w-px bg-slate-800 hidden md:block"></div>

//                   <div className="text-center md:text-right">
//                     <h3 className="text-slate-500 font-bold uppercase text-xs tracking-wider mb-3">Final Verdict</h3>
//                     <span className={`px-6 py-2 rounded-full text-white font-bold text-sm shadow-lg flex items-center gap-2 ${
//                       riskScore > 50 
//                         ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50 shadow-rose-900/20' 
//                         : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-emerald-900/20'
//                     }`}>
//                       {riskScore > 50 ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
//                       {riskScore > 50 ? "HIGH RISK DETECTED" : "SAFE TO BID"}
//                     </span>
//                   </div>
//                 </div>

//                 {/* Analysis Details Grid */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   {/* Budget Card */}
//                   <div className="p-6 bg-slate-800/40 rounded-xl border border-slate-700/50 hover:bg-slate-800/60 transition-colors">
//                     <div className="flex items-center gap-3 mb-4">
//                       <div className="p-2 bg-blue-500/10 rounded-lg">
//                         <DollarSign className="w-5 h-5 text-blue-400" />
//                       </div>
//                       <h4 className="font-bold text-slate-200">Budget Analysis</h4>
//                     </div>
//                     <p className="text-sm text-slate-400 leading-relaxed">
//                       {/* FIX 2: Added backticks for string interpolation inside ternary */}
//                       {tenderData.tender_value && tenderData.tender_value !== 'NA' 
//                         ? `Budget defined at ${tenderData.tender_value}. The values appear consistent with market standards for this region.` 
//                         : "⚠️ Budget is not clearly defined in the extracted data. This creates significant cost overrun risks and ambiguity."}
//                     </p>
//                   </div>

//                   {/* Timeline Card */}
//                   <div className="p-6 bg-slate-800/40 rounded-xl border border-slate-700/50 hover:bg-slate-800/60 transition-colors">
//                     <div className="flex items-center gap-3 mb-4">
//                       <div className="p-2 bg-purple-500/10 rounded-lg">
//                         <Calendar className="w-5 h-5 text-purple-400" />
//                       </div>
//                       <h4 className="font-bold text-slate-200">Timeline Check</h4>
//                     </div>
//                     <p className="text-sm text-slate-400 leading-relaxed">
//                       {/* FIX 3: Added backticks for string interpolation inside ternary */}
//                       {tenderData.bid_submission_end 
//                         ? `Submission deadline is set for ${tenderData.bid_submission_end}. Ensure all compliance documents are ready 48h prior.` 
//                         : "⚠️ Critical dates are missing from the extraction. Timeline risk is high; manual verification recommended."}
//                     </p>
//                   </div>
//                 </div>
                
//                 {/* Full Report Link */}
//                 <div className="p-4 rounded-xl bg-sky-500/5 border border-sky-500/10 text-center">
//                   <p className="text-slate-400 text-sm">
//                     Detailed PDF Report generated. <button className="text-sky-400 hover:text-sky-300 font-semibold hover:underline">Download Full Analysis</button>
//                   </p>
//                 </div>

//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AnalysisPage;









// import React, { useEffect, useState } from "react";
// import { useLocation, useNavigate, useParams } from "react-router-dom"; // Import useParams
// import { 
//   ArrowLeft, 
//   AlertTriangle, 
//   CheckCircle, 
//   DollarSign, 
//   Calendar, 
//   Activity,
//   Loader2
// } from "lucide-react";
// // import axios from 'axios'; // Uncomment when ready for backend integration

// const AnalysisPage = () => {
//   const { id } = useParams(); // Get ID from URL
//   const location = useLocation();
//   const navigate = useNavigate();

//   // State
//   const [tenderData, setTenderData] = useState(location.state?.tenderData || null);
//   const [riskScore, setRiskScore] = useState(0);
//   const [status, setStatus] = useState("Analyzing...");
//   const [loading, setLoading] = useState(!location.state?.tenderData); // Loading if we don't have state

//   // Effect 1: Fetch Data if missing (Handle Refresh)
//   useEffect(() => {
//     const fetchData = async () => {
//       if (!tenderData) {
//         try {
//           // TODO: Replace with your actual API call
//           // const response = await axios.get(`/api/tenders/${id}`);
//           // setTenderData(response.data);
          
//           // MOCKING THE FETCH FOR NOW:
//           console.log(`Fetching data for ID: ${id} from backend...`);
//           setTimeout(() => {
//              // Simulating a backend response
//              setTenderData({
//                 _id: id,
//                 title: "Recovered Project Data",
//                 tender_value: "50 Cr",
//                 emd_amount: "5 Lakhs",
//                 bid_submission_end: "2025-12-20"
//              });
//              setLoading(false);
//           }, 1000);

//         } catch (error) {
//           console.error("Failed to fetch tender", error);
//           navigate('/user/dashboard'); // Only redirect if fetch fails
//         }
//       }
//     };

//     fetchData();
//   }, [id, tenderData, navigate]);

//   // Effect 2: Run Risk Analysis (Once data is present)
//   useEffect(() => {
//     if (!tenderData) return;

//     setStatus("Analyzing...");
    
//     // Simulate complex Python analysis delay
//     const timer = setTimeout(() => {
//         let score = 15; // Base Risk
        
//         // Logic: Higher score = Higher Risk
//         if (!tenderData.tender_value || tenderData.tender_value === 'NA') {
//             score += 40; 
//         }

//         if (!tenderData.emd_amount || tenderData.emd_amount === 'NA') {
//             score += 20;
//         }

//         setRiskScore(score);
//         setStatus("Complete");
//     }, 1500);

//     return () => clearTimeout(timer);
//   }, [tenderData]);

//   // Early return for initial loading (before we have data)
//   if (loading) {
//     return (
//       <div className="min-h-screen bg-slate-950 flex items-center justify-center">
//          <Loader2 className="w-10 h-10 text-sky-500 animate-spin" />
//       </div>
//     );
//   }

//   // If fetch failed and we are redirecting, or data is null
//   if (!tenderData) return null;

//   // --- RENDER ---
//   return (
//     <div className="min-h-screen bg-slate-950 relative overflow-hidden p-6 md:p-10 font-sans text-slate-100">
      
//       {/* Background Ambience */}
//       <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
//       <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[128px] pointer-events-none"></div>
//       <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-600/10 rounded-full blur-[128px] pointer-events-none"></div>

//       <div className="max-w-4xl mx-auto relative z-10">
        
//         {/* Back Button */}
//         <button 
//           onClick={() => navigate('/user/dashboard')} 
//           className="mb-6 flex items-center gap-2 text-slate-400 hover:text-sky-400 transition-colors group"
//         >
//           <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
//           Back to Dashboard
//         </button>

//         <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-fadeIn">
        
//           {/* Header */}
//           <div className="bg-slate-900/80 border-b border-slate-800 p-8">
//             <div className="flex items-center gap-3 mb-2">
//               <Activity className="text-sky-400 w-6 h-6" />
//               <h1 className="text-2xl font-bold text-slate-100">Tender Risk Analysis</h1>
//             </div>
//             <p className="text-slate-400 text-sm pl-9">
//               AI-Driven Assessment for: <span className="text-slate-200 font-semibold">{tenderData.title || "Untitled Project"}</span>
//             </p>
//           </div>

//           <div className="p-8">
//             {/* Analysis Loading State */}
//             {status === "Analyzing..." ? (
//               <div className="text-center py-20 flex flex-col items-center">
//                 <Loader2 className="w-12 h-12 text-sky-500 animate-spin mb-6" />
//                 <h3 className="text-xl font-bold text-slate-200 mb-2">Analyzing Tender Document</h3>
//                 <p className="text-slate-500">Running financial checks, compliance verification, and risk modeling...</p>
//               </div>
//             ) : (
//               <div className="space-y-8 animate-fadeIn">
                  
//                 {/* Risk Score Card */}
//                 <div className="flex flex-col md:flex-row items-center justify-between bg-slate-950/50 p-8 rounded-xl border border-slate-800 gap-6">
//                   <div>
//                     <h3 className="text-slate-500 font-bold uppercase text-xs tracking-wider mb-2">Predicted Risk Score</h3>
//                     <div className="flex items-baseline gap-2">
//                       <span className={`text-5xl font-extrabold ${riskScore > 50 ? 'text-rose-500' : 'text-emerald-500'}`}>
//                         {riskScore}
//                       </span>
//                       <span className="text-slate-600 text-xl font-medium">/ 100</span>
//                     </div>
//                   </div>
                  
//                   <div className="h-12 w-px bg-slate-800 hidden md:block"></div>

//                   <div className="text-center md:text-right">
//                     <h3 className="text-slate-500 font-bold uppercase text-xs tracking-wider mb-3">Final Verdict</h3>
//                     <span className={`px-6 py-2 rounded-full text-white font-bold text-sm shadow-lg flex items-center gap-2 ${
//                       riskScore > 50 
//                         ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50 shadow-rose-900/20' 
//                         : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-emerald-900/20'
//                     }`}>
//                       {riskScore > 50 ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
//                       {riskScore > 50 ? "HIGH RISK DETECTED" : "SAFE TO BID"}
//                     </span>
//                   </div>
//                 </div>

//                 {/* Analysis Details Grid */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   {/* Budget Card */}
//                   <div className="p-6 bg-slate-800/40 rounded-xl border border-slate-700/50 hover:bg-slate-800/60 transition-colors">
//                     <div className="flex items-center gap-3 mb-4">
//                       <div className="p-2 bg-blue-500/10 rounded-lg">
//                         <DollarSign className="w-5 h-5 text-blue-400" />
//                       </div>
//                       <h4 className="font-bold text-slate-200">Budget Analysis</h4>
//                     </div>
//                     <p className="text-sm text-slate-400 leading-relaxed">
//                       {tenderData.tender_value && tenderData.tender_value !== 'NA' 
//                         ? `Budget defined at ${tenderData.tender_value}. The values appear consistent with market standards.` 
//                         : "⚠️ Budget is not clearly defined in the extracted data. This creates significant cost overrun risks."}
//                     </p>
//                   </div>

//                   {/* Timeline Card */}
//                   <div className="p-6 bg-slate-800/40 rounded-xl border border-slate-700/50 hover:bg-slate-800/60 transition-colors">
//                     <div className="flex items-center gap-3 mb-4">
//                       <div className="p-2 bg-purple-500/10 rounded-lg">
//                         <Calendar className="w-5 h-5 text-purple-400" />
//                       </div>
//                       <h4 className="font-bold text-slate-200">Timeline Check</h4>
//                     </div>
//                     <p className="text-sm text-slate-400 leading-relaxed">
//                       {tenderData.bid_submission_end 
//                         ? `Submission deadline is set for ${tenderData.bid_submission_end}. Ensure all compliance documents are ready.` 
//                         : "⚠️ Critical dates are missing from the extraction. Timeline risk is high."}
//                     </p>
//                   </div>
//                 </div>
                
//                 {/* Full Report Link */}
//                 <div className="p-4 rounded-xl bg-sky-500/5 border border-sky-500/10 text-center">
//                   <p className="text-slate-400 text-sm">
//                     Detailed PDF Report generated. <button className="text-sky-400 hover:text-sky-300 font-semibold hover:underline">Download Full Analysis</button>
//                   </p>
//                 </div>

//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AnalysisPage;








// import React, { useEffect, useState } from "react";
// import { useLocation, useNavigate, useParams } from "react-router-dom";
// import { 
//   ArrowLeft, 
//   AlertTriangle, 
//   CheckCircle, 
//   DollarSign, 
//   Calendar, 
//   Activity,
//   Loader2,
//   FileCheck,
//   Scale,
//   ShieldAlert,
//   Briefcase,
//   TrendingUp,
//   Info
// } from "lucide-react";

// const AnalysisPage = () => {
//   const { id } = useParams();
//   const location = useLocation();
//   const navigate = useNavigate();

//   // State
//   const [tenderData, setTenderData] = useState(location.state?.tenderData || null);
//   const [riskScore, setRiskScore] = useState(0);
//   const [status, setStatus] = useState("Analyzing...");
//   const [loading, setLoading] = useState(!location.state?.tenderData);

//   // --- 1. Fetch Data Logic (Enhanced Mock) ---
//   useEffect(() => {
//     const fetchData = async () => {
//       if (!tenderData) {
//         try {
//           console.log(`Fetching deep-dive data for ID: ${id}...`);
          
//           // MOCK BACKEND RESPONSE WITH MORE FIELDS
//           setTimeout(() => {
//              setTenderData({
//                 _id: id,
//                 title: "Construction of Multi-Level Parking at Sector-5, Guwahati",
//                 authority: "M-DoNER / PWD Assam",
//                 tender_value: "50 Cr",
//                 emd_amount: "50 Lakhs",
//                 tender_fee: "10,000 INR",
//                 bid_submission_end: "2025-12-20",
//                 contract_period: "24 Months",
                
//                 // New Deep Dive Fields
//                 financial_eligibility: {
//                     avg_turnover: "15 Cr (Last 3 Years)",
//                     solvency: "20 Cr",
//                     net_worth: "Positive"
//                 },
//                 technical_eligibility: [
//                     "Completed 1 similar work of 40 Cr",
//                     "Or 2 similar works of 25 Cr each",
//                     "RCC Structure Experience > 5 Years"
//                 ],
//                 compliance_check: {
//                     gst_status: "Required",
//                     pan_card: "Required",
//                     epf_registration: "Required",
//                     litigation_history: "Clean Record Needed"
//                 },
//                 hidden_clauses: [
//                     { type: "high_risk", text: "Liquidated Damages: 1% per week (Max 10%)" },
//                     { type: "medium_risk", text: "Price Variation: Not Applicable for first 12 months" },
//                     { type: "neutral", text: "Defect Liability Period: 3 Years" }
//                 ]
//              });
//              setLoading(false);
//           }, 1500);

//         } catch (error) {
//           console.error("Failed to fetch tender", error);
//           navigate('/user/dashboard');
//         }
//       }
//     };

//     fetchData();
//   }, [id, tenderData, navigate]);

//   // --- 2. AI Risk Algorithm (Enhanced) ---
//   useEffect(() => {
//     if (!tenderData) return;

//     setStatus("Analyzing...");
    
//     const timer = setTimeout(() => {
//         let score = 15; // Base Risk
        
//         // 1. Budget Risk
//         if (!tenderData.tender_value || tenderData.tender_value === 'NA') score += 25;

//         // 2. Timeline Risk (Simple check: is it less than 15 days away?)
//         const deadline = new Date(tenderData.bid_submission_end);
//         const today = new Date();
//         const daysLeft = (deadline - today) / (1000 * 60 * 60 * 24);
//         if (daysLeft < 10) score += 15;

//         // 3. Clause Risk (Mock logic based on hidden clauses)
//         if (tenderData.hidden_clauses?.some(c => c.type === 'high_risk')) score += 20;

//         setRiskScore(score);
//         setStatus("Complete");
//     }, 2000); // Slightly longer for dramatic effect

//     return () => clearTimeout(timer);
//   }, [tenderData]);

//   // --- Loading View ---
//   if (loading) {
//     return (
//       <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-4">
//          <Loader2 className="w-12 h-12 text-sky-500 animate-spin" />
//          <p className="text-slate-500 font-mono text-sm">Retrieving Deep Dive Data...</p>
//       </div>
//     );
//   }

//   if (!tenderData) return null;

//   // --- Helper for Risk Badges ---
//   const getRiskBadge = (type) => {
//       switch(type) {
//           case 'high_risk': return <span className="text-[10px] font-bold bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30">HIGH RISK</span>;
//           case 'medium_risk': return <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">CAUTION</span>;
//           default: return <span className="text-[10px] font-bold bg-slate-700 text-slate-300 px-2 py-0.5 rounded border border-slate-600">INFO</span>;
//       }
//   };

//   // --- MAIN RENDER ---
//   return (
//     <div className="min-h-screen bg-slate-950 relative overflow-hidden p-4 md:p-8 font-sans text-slate-100">
      
//       {/* Background Ambience */}
//       <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-5 pointer-events-none"></div>
//       <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[128px] pointer-events-none"></div>

//       <div className="max-w-6xl mx-auto relative z-10">
        
//         {/* Nav */}
//         <button 
//           onClick={() => navigate('/user/dashboard')} 
//           className="mb-6 flex items-center gap-2 text-slate-400 hover:text-sky-400 transition-colors group text-sm font-medium"
//         >
//           <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
//           Back to Dashboard
//         </button>

//         {/* --- MAIN HEADER SECTION --- */}
//         <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-6 md:p-8 mb-6 shadow-2xl relative overflow-hidden">
//             <div className="absolute top-0 right-0 p-4 opacity-10">
//                 <Activity className="w-32 h-32 text-slate-100" />
//             </div>

//             <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
//                 <div>
//                     <div className="flex items-center gap-2 mb-2">
//                         <span className="bg-sky-500/10 text-sky-400 border border-sky-500/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
//                             AI Audit Complete
//                         </span>
//                         <span className="text-slate-500 text-xs flex items-center gap-1">
//                             <Calendar className="w-3 h-3" /> {new Date().toLocaleDateString()}
//                         </span>
//                     </div>
//                     <h1 className="text-2xl md:text-3xl font-bold text-white mb-2 leading-tight max-w-2xl">
//                         {tenderData.title}
//                     </h1>
//                     <p className="text-slate-400 text-sm flex items-center gap-2">
//                         <Briefcase className="w-4 h-4" /> Authority: <span className="text-slate-200">{tenderData.authority || "Unknown Authority"}</span>
//                     </p>
//                 </div>

//                 {/* Score Circle */}
//                 {status === "Complete" && (
//                     <div className="flex items-center gap-4 bg-slate-950/50 p-4 rounded-xl border border-slate-800">
//                         <div className="text-right">
//                             <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Risk Score</p>
//                             <p className={`text-3xl font-extrabold ${riskScore > 50 ? 'text-rose-500' : 'text-emerald-400'}`}>
//                                 {riskScore}<span className="text-lg text-slate-600">/100</span>
//                             </p>
//                         </div>
//                         <div className={`w-2 h-12 rounded-full ${riskScore > 50 ? 'bg-rose-500' : 'bg-emerald-500'}`}></div>
//                     </div>
//                 )}
//             </div>
//         </div>

//         {/* --- LOADING STATE FOR ANALYSIS --- */}
//         {status === "Analyzing..." ? (
//              <div className="text-center py-20 bg-slate-900/40 rounded-2xl border border-slate-800 border-dashed">
//                 <Loader2 className="w-10 h-10 text-sky-500 animate-spin mx-auto mb-4" />
//                 <p className="text-slate-400 animate-pulse">Running Deep Legal & Financial Scan...</p>
//              </div>
//         ) : (
//             <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
                
//                 {/* COLUMN 1: FINANCIALS & DATES */}
//                 <div className="space-y-6">
//                     {/* Financial Card */}
//                     <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors">
//                         <div className="flex items-center gap-2 mb-4 text-emerald-400">
//                             <DollarSign className="w-5 h-5" />
//                             <h3 className="font-bold text-slate-200">Financial Snapshot</h3>
//                         </div>
                        
//                         <div className="space-y-4">
//                             <div className="flex justify-between items-end border-b border-slate-800 pb-2">
//                                 <span className="text-sm text-slate-500">Tender Value</span>
//                                 <span className="font-mono font-bold text-xl text-white">{tenderData.tender_value}</span>
//                             </div>
//                             <div className="flex justify-between items-end border-b border-slate-800 pb-2">
//                                 <span className="text-sm text-slate-500">EMD Amount</span>
//                                 <span className="font-mono font-bold text-slate-200">{tenderData.emd_amount}</span>
//                             </div>
//                              <div className="flex justify-between items-end border-b border-slate-800 pb-2">
//                                 <span className="text-sm text-slate-500">Tender Fee</span>
//                                 <span className="font-mono font-bold text-slate-200">{tenderData.tender_fee}</span>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Timeline Card */}
//                     <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors">
//                         <div className="flex items-center gap-2 mb-4 text-purple-400">
//                             <Calendar className="w-5 h-5" />
//                             <h3 className="font-bold text-slate-200">Critical Dates</h3>
//                         </div>
//                         <div className="p-3 bg-slate-950/50 rounded-lg border border-slate-800 mb-3">
//                             <span className="text-xs text-slate-500 uppercase font-bold">Submission Deadline</span>
//                             <div className="text-lg text-white font-medium mt-1">{tenderData.bid_submission_end}</div>
//                             <div className="text-xs text-rose-400 mt-1 font-mono">
//                                 {/* Calculate days left mock */}
//                                 ⚠️ Only 12 Days Left
//                             </div>
//                         </div>
//                          <div className="flex justify-between items-center text-sm">
//                             <span className="text-slate-500">Contract Duration</span>
//                             <span className="text-slate-200 font-medium">{tenderData.contract_period}</span>
//                          </div>
//                     </div>
//                 </div>

//                 {/* COLUMN 2: COMPLIANCE & ELIGIBILITY */}
//                 <div className="space-y-6">
//                     {/* Compliance Matrix */}
//                     <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors h-full">
//                         <div className="flex items-center gap-2 mb-4 text-blue-400">
//                             <FileCheck className="w-5 h-5" />
//                             <h3 className="font-bold text-slate-200">Compliance Matrix</h3>
//                         </div>

//                         <div className="space-y-3">
//                             {tenderData.compliance_check && Object.entries(tenderData.compliance_check).map(([key, value]) => (
//                                 <div key={key} className="flex items-center justify-between p-2 rounded hover:bg-slate-800/50 transition-colors">
//                                     <span className="text-sm text-slate-400 capitalize">{key.replace('_', ' ')}</span>
//                                     <div className="flex items-center gap-2">
//                                         <span className="text-xs text-slate-500">{value}</span>
//                                         <CheckCircle className="w-4 h-4 text-emerald-500" />
//                                     </div>
//                                 </div>
//                             ))}
//                         </div>

//                         <div className="mt-6 pt-4 border-t border-slate-800">
//                             <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Technical Eligibility</h4>
//                             <ul className="space-y-2">
//                                 {tenderData.technical_eligibility?.map((item, i) => (
//                                     <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
//                                         <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0"></div>
//                                         {item}
//                                     </li>
//                                 ))}
//                             </ul>
//                         </div>
//                     </div>
//                 </div>

//                 {/* COLUMN 3: LEGAL & RISK */}
//                 <div className="space-y-6">
//                     {/* Legal Clause Analysis */}
//                     <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors h-full">
//                         <div className="flex items-center gap-2 mb-4 text-rose-400">
//                             <Scale className="w-5 h-5" />
//                             <h3 className="font-bold text-slate-200">Legal & Clause Scan</h3>
//                         </div>

//                         <div className="space-y-3">
//                              {tenderData.hidden_clauses?.map((clause, i) => (
//                                 <div key={i} className="p-3 bg-slate-950/30 border border-slate-800 rounded-lg group hover:border-slate-600 transition-colors">
//                                     <div className="flex justify-between items-start mb-1">
//                                         <span className="text-xs text-slate-500">Clause #{i+1}</span>
//                                         {getRiskBadge(clause.type)}
//                                     </div>
//                                     <p className="text-sm text-slate-300 leading-snug">
//                                         {clause.text}
//                                     </p>
//                                 </div>
//                              ))}
//                         </div>

//                         <div className="mt-4 p-3 bg-amber-500/5 border border-amber-500/10 rounded-lg flex gap-3">
//                             <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
//                             <p className="text-xs text-amber-200/80 leading-relaxed">
//                                 <strong>AI Insight:</strong> The "Liquidated Damages" clause is stricter than standard M-DoNER templates. Ensure strict schedule adherence.
//                             </p>
//                         </div>
//                     </div>
//                 </div>

//             </div>
//         )}

//         {/* Action Bar */}
//         {status === "Complete" && (
//             <div className="mt-8 flex justify-end gap-4 animate-fadeIn">
//                 <button className="px-6 py-3 rounded-xl border border-slate-700 text-slate-300 font-medium hover:bg-slate-800 transition-colors flex items-center gap-2">
//                     <TrendingUp className="w-4 h-4" /> Compare with Similar Tenders
//                 </button>
//                 <button className="px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold shadow-lg shadow-sky-900/20 transition-all flex items-center gap-2">
//                     <CheckCircle className="w-4 h-4" /> Generate Bid Proposal
//                 </button>
//             </div>
//         )}

//       </div>
//     </div>
//   );
// };

// export default AnalysisPage;












import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign, 
  Calendar, 
  Activity,
  Loader2,
  FileCheck,
  Scale,
  MapPin,
  Building2,
  TrendingUp,
  FileText
} from "lucide-react";

const AnalysisPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  // State
  const [tenderData, setTenderData] = useState(location.state?.tenderData || null);
  const [riskDetails, setRiskDetails] = useState({ score: 0, factors: [] });
  const [status, setStatus] = useState("Initializing...");
  const [loading, setLoading] = useState(!location.state?.tenderData);

  // --- 1. Data Fetching (Handle Refresh) ---
  useEffect(() => {
    const fetchData = async () => {
      if (!tenderData) {
        try {
          setStatus("Fetching Data...");
          
          // Replace with your actual Single Tender API endpoint
          // const response = await fetch(`http://localhost:5000/api/dpr/${id}`);
          // const result = await response.json();
          
          // MOCK SIMULATION (Matches your MyTender structure)
          console.log(`Fetching data for ID: ${id}...`);
          setTimeout(() => {
             // Simulating what your DB likely returns
             const mockDbResponse = {
                _id: id,
                extractedData: {
                    project_name: "Construction of Model High School Building",
                    location: "Vadodara, Gujarat",
                    cost_grand_total: "12.5", // Cr
                    total_built_up_area: "45000", // Sq.ft
                    emd_amount: "250000",
                    tender_fee: "5000",
                    bid_submission_end: "2025-12-15",
                    agency: "R&B Division",
                    gst_no: "Required",
                    pan_required: "Yes"
                },
                riskAnalysis: {
                    score: 0 // Assume we need to calculate it if it's 0
                },
                createdAt: new Date().toISOString()
             };

             // Flatten structure to match handleViewAnalysis logic
             const formatted = {
                ...mockDbResponse.extractedData,
                _id: mockDbResponse._id,
                riskAnalysis: mockDbResponse.riskAnalysis,
                createdAt: mockDbResponse.createdAt
             };

             setTenderData(formatted);
             setLoading(false);
          }, 1000);

        } catch (error) {
          console.error("Failed to fetch tender", error);
          navigate('/user/dashboard');
        }
      }
    };

    fetchData();
  }, [id, tenderData, navigate]);

  // --- 2. Dynamic Risk Prediction Logic ---
  useEffect(() => {
    if (!tenderData) return;

    setStatus("Analyzing...");
    
    const analyzeRisk = () => {
        let score = 10; // Base Score
        let factors = [];

        // Factor 1: Cost Analysis
        if (!tenderData.cost_grand_total || tenderData.cost_grand_total === 'NA') {
            score += 30;
            factors.push({ type: 'high', text: "Total Cost is undefined (High Financial Risk)" });
        } else {
            factors.push({ type: 'safe', text: `Budget defined: ${tenderData.cost_grand_total} Cr` });
        }

        // Factor 2: Timeline Analysis
        if (tenderData.bid_submission_end) {
            const deadline = new Date(tenderData.bid_submission_end);
            const today = new Date();
            const daysLeft = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
            
            if (daysLeft < 0) {
                score += 50;
                factors.push({ type: 'critical', text: "Deadline has passed" });
            } else if (daysLeft < 7) {
                score += 20;
                factors.push({ type: 'medium', text: `Urgent: Only ${daysLeft} days remaining` });
            } else {
                factors.push({ type: 'safe', text: `Healthy Timeline: ${daysLeft} days left` });
            }
        } else {
            score += 25;
            factors.push({ type: 'high', text: "Submission Deadline missing in document" });
        }

        // Factor 3: Data Completeness (Area/Location)
        if (!tenderData.total_built_up_area) {
             score += 10;
             factors.push({ type: 'medium', text: "Built-up Area not specified" });
        }
        
        if (!tenderData.location) {
             score += 10;
             factors.push({ type: 'medium', text: "Project Location is ambiguous" });
        }

        // Cap score at 100
        score = Math.min(score, 100);

        // Update State
        setRiskDetails({ score, factors });
        setStatus("Complete");
    };

    const timer = setTimeout(analyzeRisk, 1500); // Simulate processing time
    return () => clearTimeout(timer);
  }, [tenderData]);

  // --- Helper: Render Risk Factor Badge ---
  const renderFactorBadge = (type) => {
    const styles = {
        safe: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
        medium: "text-amber-400 bg-amber-500/10 border-amber-500/20",
        high: "text-rose-400 bg-rose-500/10 border-rose-500/20",
        critical: "text-red-500 bg-red-500/10 border-red-500/20 font-bold"
    };
    return styles[type] || styles.medium;
  };

  // --- Loading View ---
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-4">
         <Loader2 className="w-12 h-12 text-sky-500 animate-spin" />
         <p className="text-slate-500 font-mono text-sm">{status}</p>
      </div>
    );
  }

  if (!tenderData) return null;

  // --- MAIN UI ---
  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden p-4 md:p-8 font-sans text-slate-100">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-5 pointer-events-none"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-sky-600/10 rounded-full blur-[128px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Nav */}
        <button 
          onClick={() => navigate('/user/dashboard')} 
          className="mb-6 flex items-center gap-2 text-slate-400 hover:text-sky-400 transition-colors group text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Back to Dashboard
        </button>

        {/* --- HEADER: Project Title & Context --- */}
        <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-6 md:p-8 mb-6 shadow-2xl">
            <div className="flex flex-col md:flex-row justify-between items-start gap-6">
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                        <span className="bg-sky-500/10 text-sky-400 border border-sky-500/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                            Analyzed Document
                        </span>
                        <span className="text-slate-500 text-xs flex items-center gap-1 font-mono">
                            <Calendar className="w-3 h-3" /> Uploaded: {new Date(tenderData.createdAt).toLocaleDateString()}
                        </span>
                    </div>
                    <h1 className="text-2xl md:text-3xl font-bold text-white mb-2 leading-tight">
                        {tenderData.project_name || "Untitled Project Name"}
                    </h1>
                    <div className="flex flex-wrap gap-4 text-sm text-slate-400 mt-3">
                        <div className="flex items-center gap-1.5">
                            <MapPin className="w-4 h-4 text-slate-500" />
                            {tenderData.location || "Location Unknown"}
                        </div>
                        <div className="flex items-center gap-1.5">
                            <Building2 className="w-4 h-4 text-slate-500" />
                            {tenderData.total_built_up_area ? `${tenderData.total_built_up_area} sq.ft` : "Area Unknown"}
                        </div>
                    </div>
                </div>

                {/* Dynamic Score Display */}
                {status === "Complete" && (
                    <div className="flex items-center gap-5 bg-slate-950/80 p-5 rounded-xl border border-slate-800 shadow-inner min-w-[200px]">
                        <div className="text-right">
                            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Risk Score</p>
                            <div className="flex items-baseline justify-end gap-1">
                                <span className={`text-4xl font-extrabold ${riskDetails.score > 50 ? 'text-rose-500' : 'text-emerald-400'}`}>
                                    {riskDetails.score}
                                </span>
                                <span className="text-slate-600 text-sm font-medium">/100</span>
                            </div>
                        </div>
                        <div className={`h-16 w-1.5 rounded-full ${riskDetails.score > 50 ? 'bg-rose-500' : 'bg-emerald-500'}`}></div>
                    </div>
                )}
            </div>
        </div>

        {/* --- MAIN GRID --- */}
        {status === "Analyzing..." ? (
             <div className="text-center py-20 bg-slate-900/40 rounded-2xl border border-slate-800 border-dashed">
                <Loader2 className="w-10 h-10 text-sky-500 animate-spin mx-auto mb-4" />
                <p className="text-slate-400 animate-pulse">Running AI Analysis on extracted fields...</p>
             </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
                
                {/* 1. FINANCIALS */}
                <div className="space-y-6">
                    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors h-full">
                        <div className="flex items-center gap-2 mb-5 text-emerald-400">
                            <DollarSign className="w-5 h-5" />
                            <h3 className="font-bold text-slate-200">Financials</h3>
                        </div>
                        
                        <div className="space-y-5">
                            <div>
                                <span className="text-xs text-slate-500 uppercase font-bold">Total Estimated Cost</span>
                                <div className="text-2xl font-mono text-white mt-1">
                                    {tenderData.cost_grand_total ? `${tenderData.cost_grand_total} Cr` : <span className="text-rose-400 text-lg">Not Found</span>}
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-slate-950/50 p-3 rounded-lg border border-slate-800">
                                    <span className="text-[10px] text-slate-500 uppercase block mb-1">EMD Amount</span>
                                    <span className="font-mono text-slate-300">
                                        {tenderData.emd_amount ? `₹${tenderData.emd_amount}` : "N/A"}
                                    </span>
                                </div>
                                <div className="bg-slate-950/50 p-3 rounded-lg border border-slate-800">
                                    <span className="text-[10px] text-slate-500 uppercase block mb-1">Tender Fee</span>
                                    <span className="font-mono text-slate-300">
                                        {tenderData.tender_fee ? `₹${tenderData.tender_fee}` : "N/A"}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 2. DATES & DEADLINES */}
                <div className="space-y-6">
                    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors h-full">
                        <div className="flex items-center gap-2 mb-5 text-purple-400">
                            <Calendar className="w-5 h-5" />
                            <h3 className="font-bold text-slate-200">Timeline</h3>
                        </div>

                        <div className="space-y-4">
                            <div className="relative pl-4 border-l-2 border-slate-800">
                                <span className="text-xs text-slate-500 uppercase font-bold">Submission End Date</span>
                                <div className="text-lg text-white font-medium mt-1">
                                    {tenderData.bid_submission_end || <span className="text-rose-400">Missing Date</span>}
                                </div>
                            </div>
                            
                            {tenderData.bid_submission_end && (
                                <div className="p-3 bg-purple-500/5 border border-purple-500/10 rounded-lg text-sm text-purple-200">
                                    ℹ️ Ensure bid documents are uploaded 24h before deadline.
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* 3. AI RISK FACTORS (Generated Logic) */}
                <div className="space-y-6">
                    <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors h-full">
                        <div className="flex items-center gap-2 mb-5 text-amber-400">
                            <Scale className="w-5 h-5" />
                            <h3 className="font-bold text-slate-200">Risk Assessment</h3>
                        </div>

                        <div className="space-y-3">
                             {riskDetails.factors.map((factor, index) => (
                                <div key={index} className={`p-3 rounded-lg border flex items-start gap-3 ${renderFactorBadge(factor.type)}`}>
                                    {factor.type === 'safe' ? <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" /> : <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />}
                                    <p className="text-sm leading-snug font-medium">
                                        {factor.text}
                                    </p>
                                </div>
                             ))}
                             
                             {riskDetails.factors.length === 0 && (
                                <p className="text-slate-500 text-sm">No significant risks detected based on available data.</p>
                             )}
                        </div>
                    </div>
                </div>

            </div>
        )}

        {/* --- RAW DATA (For Debugging / Transparency) --- */}
        {status === "Complete" && (
            <div className="mt-8 p-6 bg-slate-950 rounded-xl border border-slate-800 opacity-70 hover:opacity-100 transition-opacity">
                <div className="flex items-center gap-2 mb-4 text-slate-500">
                    <FileText className="w-4 h-4" />
                    <h4 className="text-xs font-bold uppercase tracking-wider">Extracted Data Points</h4>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(tenderData).map(([key, value]) => {
                        if(typeof value === 'object' || key === '_id' || key === 'riskAnalysis') return null;
                        return (
                            <div key={key} className="overflow-hidden">
                                <span className="text-[10px] text-slate-600 uppercase block mb-0.5">{key.replace(/_/g, " ")}</span>
                                <span className="text-sm text-slate-300 truncate block" title={value}>{value}</span>
                            </div>
                        )
                    })}
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default AnalysisPage;