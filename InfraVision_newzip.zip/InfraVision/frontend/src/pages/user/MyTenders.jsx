// import { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";

// const MyTenders = () => {
//   const [tenders, setTenders] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigate = useNavigate();

//   // 1. Get current User ID (assuming you stored it in localStorage on Login)
//   // If you store it as 'user', you might need JSON.parse(localStorage.getItem('user'))._id
//   const userId = localStorage.getItem("userId") || "guest_user"; 

//   useEffect(() => {
//     fetchTenders();
//   }, []);

//   const fetchTenders = async () => {
//     try {
//       const response = await fetch(`http://localhost:5000/api/tenders/user/${userId}`);
//       const result = await response.json();
//       if (result.status === "success") {
//         setTenders(result.data);
//       }
//     } catch (error) {
//       console.error("Error fetching history:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Navigate to Analysis Page with the specific tender data
//   const handleCardClick = (tender) => {
//     navigate('/user/analysis', { state: { tenderData: tender } });
//   };

//   return (
//     <div className="min-h-screen bg-[#F1F6F9] p-6 md:p-10">
//       <div className="max-w-7xl mx-auto">
        
//         <div className="flex justify-between items-end mb-8">
//           <div>
//             <h1 className="text-3xl font-bold text-[#212A3E]">My Tender Dashboard</h1>
//             <p className="text-[#394867] mt-2">View and manage your uploaded documents.</p>
//           </div>
//           <button 
//             onClick={() => navigate('/user/upload')} // Assuming '/user' is the upload page
//             className="bg-[#212A3E] text-white px-5 py-2 rounded-lg font-semibold hover:bg-[#394867] transition"
//           >
//             + Upload New
//           </button>
//         </div>

//         {loading ? (
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             {[1, 2, 3].map((i) => (
//               <div key={i} className="h-64 bg-gray-200 rounded-2xl animate-pulse"></div>
//             ))}
//           </div>
//         ) : tenders.length === 0 ? (
//           <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-300">
//             <p className="text-xl text-gray-400 font-semibold">No tenders uploaded yet.</p>
//             <button onClick={() => navigate('/user/upload')} className="text-[#394867] underline mt-2">Start by uploading one</button>
//           </div>
//         ) : (
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-fade-in">
//             {tenders.map((tender) => (
//               <div 
//                 key={tender._id} 
//                 onClick={() => handleCardClick(tender)}
//                 className="bg-white rounded-2xl shadow-sm hover:shadow-xl border border-gray-100 transition-all duration-300 cursor-pointer group overflow-hidden flex flex-col h-full"
//               >
//                 {/* Card Header */}
//                 <div className="p-6 border-b border-gray-100 bg-gray-50 group-hover:bg-[#212A3E] group-hover:text-white transition-colors">
//                   <div className="flex justify-between items-start">
//                     <h3 className="font-bold text-lg line-clamp-2 h-14">
//                       {tender.title || "Untitled Tender Document"}
//                     </h3>
//                     <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded group-hover:bg-white group-hover:text-[#212A3E]">
//                        PDF
//                     </span>
//                   </div>
//                   <p className="text-xs text-gray-500 mt-2 group-hover:text-gray-300">
//                     Ref: {tender.tender_reference_number || "N/A"}
//                   </p>
//                 </div>

//                 {/* Card Body */}
//                 <div className="p-6 flex-grow">
//                   <div className="space-y-4">
//                     <div className="flex items-center justify-between">
//                       <span className="text-xs font-bold text-gray-400 uppercase">Budget</span>
//                       <span className="font-bold text-green-600">
//                         {tender.tender_value || "Not Specified"}
//                       </span>
//                     </div>
                    
//                     <div className="flex items-center justify-between">
//                       <span className="text-xs font-bold text-gray-400 uppercase">Deadline</span>
//                       <span className="text-sm text-[#394867] font-medium">
//                         {tender.bid_submission_end || "Unknown"}
//                       </span>
//                     </div>

//                     <div className="flex items-center justify-between">
//                       <span className="text-xs font-bold text-gray-400 uppercase">Location</span>
//                       <span className="text-sm text-[#394867] truncate max-w-[150px] text-right">
//                         {tender.location || "N/A"}
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Card Footer */}
//                 <div className="p-4 border-t border-gray-100 bg-gray-50 text-center">
//                   <span className="text-sm font-bold text-[#394867] group-hover:text-[#212A3E] flex items-center justify-center gap-2">
//                     View Analysis Details
//                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 group-hover:translate-x-1 transition-transform">
//                       <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
//                     </svg>
//                   </span>
//                 </div>
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default MyTenders;




import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FileText, Loader2, Search, AlertTriangle } from "lucide-react";
import DPRCard from "../../components/DPRCard"; // Adjust path if needed

const MyTender = ({ tender }) => {
  const navigate = useNavigate();
  const [tenders, setTenders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // 1. Fetch Data
  useEffect(() => {
    const fetchHistory = async () => {
      const userId = localStorage.getItem("userId");
      
      if (!userId) {
        setError("User not logged in.");
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`http://localhost:5000/api/dpr/history/${userId}`);
        const result = await response.json();

        if (response.ok && result.status === "success") {
          setTenders(result.data);
        } else {
          setError("Failed to load history.");
        }
      } catch (err) {
        console.error(err);
        setError("Server error. Could not fetch data.");
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  // // 2. Navigation Handler
  // const handleViewAnalysis = (tender) => {
  //   const analysisPayload = {
  //     extractedData: tender.extractedData,
  //     riskAnalysis: tender.riskAnalysis
  //   };
  //   navigate("/user/analysis", { state: { analysisResult: analysisPayload } });
  // };

  // 2. Navigation Handler
  const handleViewAnalysis = (tender) => {
    // We flatten the data so AnalysisPage can access properties like 'tenderData.tender_value' directly
    const formattedData = {
        ...tender.extractedData,     // Spread extracted fields (project_name, cost, etc.) to top level
        _id: tender._id,
        riskAnalysis: tender.riskAnalysis,
        createdAt: tender.createdAt
    };

    // Navigate to /user/analysis/ID with the formatted data in state
    navigate(`/user/analysis/${tender._id}`, { 
        state: { tenderData: formattedData } 
    });
  };
  

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden p-6 md:p-10 font-sans text-slate-100">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[128px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[128px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Page Header */}
        <div className="mb-10 flex flex-col md:flex-row justify-between items-end gap-4 border-b border-slate-800 pb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-2">
              My Uploads
            </h1>
            <p className="text-slate-400">
              History of your analyzed DPRs and Tenders.
            </p>
          </div>
          <button 
            onClick={() => navigate('/user/upload')}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 px-5 py-2.5 rounded-xl font-semibold transition-all hover:shadow-lg hover:shadow-sky-500/10"
          >
            <FileText className="w-4 h-4 text-sky-400" />
            New Upload
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500">
            <Loader2 className="w-10 h-10 animate-spin mb-3 text-sky-500" />
            <p className="animate-pulse">Loading your history...</p>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 flex items-center gap-3 animate-fadeIn">
            <AlertTriangle className="w-5 h-5" />
            {error}
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && tenders.length === 0 && (
          <div className="text-center py-20 bg-slate-900/40 rounded-3xl border border-dashed border-slate-800 animate-fadeIn">
            <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-slate-500" />
            </div>
            <h3 className="text-xl font-bold text-slate-300">No documents found</h3>
            <p className="text-slate-500 mt-2 max-w-sm mx-auto">
              It looks like you haven't uploaded any DPRs yet. Start by uploading a PDF to see your analysis history here.
            </p>
            <button 
              onClick={() => navigate('/user/upload')}
              className="mt-6 text-sky-400 font-medium hover:text-sky-300 hover:underline"
            >
              Upload your first document →
            </button>
          </div>
        )}

        {/* Grid Layout of Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
          {!loading && tenders.map((tender) => (
             <DPRCard 
               key={tender._id} 
               tender={tender} 
               onClick={handleViewAnalysis} 
             />
          ))}
        </div>

      </div>
    </div>
  );
};

export default MyTender;