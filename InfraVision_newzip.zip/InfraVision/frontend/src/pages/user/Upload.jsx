import { useState } from "react";
import axios from "axios";

const Upload = () => {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setResult(null);
    setError("");
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a PDF file");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    setLoading(true);
    setError("");

    try {
      const response = await axios.post(
        "http://localhost:8001/analyze",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setResult(response.data);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze DPR. Make sure backend is running.");
    }

    setLoading(false);
  };

  return (
    <div style={{ padding: "30px", maxWidth: "600px" }}>
      <h2>DPR Risk Analysis</h2>

      <input
        type="file"
        accept="application/pdf"
        onChange={handleFileChange}
      />

      <br /><br />

      <button onClick={handleUpload} disabled={loading}>
        {loading ? "Analyzing..." : "Upload & Analyze"}
      </button>

      {error && (
        <p style={{ color: "red", marginTop: "15px" }}>
          {error}
        </p>
      )}

      {result && (
        <div style={{ marginTop: "25px" }}>
          <h3>Risk Level: {result.risk_level}</h3>
          <p><strong>Risk Score:</strong> {result.risk_score}</p>

          <h4>Extracted Metrics</h4>
          <pre
            style={{
              background: "#f4f4f4",
              padding: "10px",
              borderRadius: "5px"
            }}
          >
            {JSON.stringify(result.metrics, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};

export default Upload;
