import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

const InvestorDashboard = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setProjects([
        { id: 1, name: "Smart City Water Supply", state: "Assam", score: 25 },
        { id: 2, name: "Rural Road Project", state: "Nagaland", score: 65 },
        { id: 3, name: "Green Energy Microgrid", state: "Manipur", score: 88 },
      ]);
      setLoading(false);
    }, 800);
  }, []);

  const getRiskColor = (score) => {
    if (score > 75) return "high";
    if (score > 40) return "medium";
    return "low";
  };

  const getRiskLabel = (score) => {
    if (score > 75) return "High Risk";
    if (score > 40) return "Medium Risk";
    return "Low Risk";
  };

  if (loading)
    return (
      <div className="flex flex-col items-center justify-center h-[90vh]">
        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4" />
        <p className="text-gray-600">Loading projects...</p>
      </div>
    );

  return (
    <div className="px-6 md:px-16 py-12 min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-white">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-3xl font-bold text-center text-blue-700 mb-2"
      >
        Investor Dashboard
      </motion.h1>
      <p className="text-center text-gray-500 mb-10">
        Analyze project feasibility and make informed investment decisions.
      </p>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => {
          const color = getRiskColor(p.score);
          const label = getRiskLabel(p.score);
          const radius = 45;
          const circumference = 2 * Math.PI * radius;
          const offset = circumference - (p.score / 100) * circumference;

          const colorClasses = {
            low: {
              border: "border-green-200",
              gradient: "from-green-400 to-emerald-500",
              text: "text-green-700",
              bgBadge: "bg-green-100 text-green-700",
            },
            medium: {
              border: "border-yellow-200",
              gradient: "from-yellow-400 to-amber-500",
              text: "text-yellow-700",
              bgBadge: "bg-yellow-100 text-yellow-700",
            },
            high: {
              border: "border-red-200",
              gradient: "from-red-500 to-rose-600",
              text: "text-red-700",
              bgBadge: "bg-red-100 text-red-700",
            },
          };

          return (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: p.id * 0.1 }}
              className={`relative overflow-hidden rounded-2xl shadow-lg border ${colorClasses[color].border} bg-white/60 backdrop-blur-md hover:shadow-2xl hover:-translate-y-1 transition-all`}
            >
              <div className="absolute inset-0 opacity-20 bg-gradient-to-br from-blue-100 via-transparent to-white" />
              <div className="relative p-6 text-center">
                <h2 className="text-lg font-semibold text-gray-800 mb-1">{p.name}</h2>
                <p className="text-sm text-gray-500 mb-4">State: {p.state}</p>

                {/* Circular Score */}
                <div className="relative w-32 h-32 mx-auto mb-4">
                  <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                    <circle
                      cx="50"
                      cy="50"
                      r={radius}
                      strokeWidth="8"
                      className="stroke-gray-200 fill-none"
                    />
                    <motion.circle
                      cx="50"
                      cy="50"
                      r={radius}
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      strokeDashoffset={circumference}
                      animate={{ strokeDashoffset: offset }}
                      transition={{ duration: 1.4, ease: "easeInOut" }}
                      className="fill-none"
                      stroke={`url(#gradient-${p.id})`}
                    />
                    <defs>
                      <linearGradient id={`gradient-${p.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" className={colorClasses[color].gradient.split(" ")[0]} />
                        <stop offset="100%" className={colorClasses[color].gradient.split(" ")[1]} />
                      </linearGradient>
                    </defs>
                  </svg>

                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.4 }}
                      className={`text-2xl font-bold ${colorClasses[color].text}`}
                    >
                      {p.score}%
                    </motion.span>
                    <p className="text-xs text-gray-500">Risk Score</p>
                  </div>
                </div>

                {/* Badge */}
                <span
                  className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${colorClasses[color].bgBadge} mb-3`}
                >
                  {label}
                </span>

                {/* Description */}
                <p className="text-sm text-gray-600 mb-5">
                  {label === "High Risk"
                    ? "⚠ Requires careful due diligence before investment."
                    : label === "Medium Risk"
                    ? "⚡ Balanced opportunity with moderate uncertainty."
                    : "✅ Stable project with good investment potential."}
                </p>

                {/* Button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`w-full py-2 font-semibold rounded-xl text-white bg-gradient-to-r ${colorClasses[color].gradient}`}
                >
                  Invest Now
                </motion.button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default InvestorDashboard;
