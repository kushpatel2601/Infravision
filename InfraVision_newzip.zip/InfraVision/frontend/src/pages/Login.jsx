// import { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import {
//   FaApple,
//   FaGoogle,
//   FaFacebookF,
//   FaEye,
//   FaEyeSlash,
// } from "react-icons/fa";
// import axios from "axios";

// const Login = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [showPassword, setShowPassword] = useState(false);
//   const [message, setMessage] = useState("");
//   const navigate = useNavigate();

//   // Ensure this matches your backend port
//   const API_BASE = "http://localhost:5000/api/auth";

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     setMessage(""); // Clear previous errors

//     try {
//       const res = await axios.post(`${API_BASE}/login`, { email, password });

//       // --- DEBUGGING: Check what the API sends ---
//       console.log("Login Success:", res.data);

//       // 1. EXTRACT DATA SAFELY
//       // Based on your DB JSON: { user: { name: "Om", type: "user", ... } }
//       const user = res.data.user;
//       const token = res.data.token;

//       // 2. SAVE TO LOCALSTORAGE
//       localStorage.setItem("token", token);

//       // Save 'type' (converted to lowercase to match your routing logic)
//       localStorage.setItem("userType", user.type.toLowerCase());

//       // Save 'name' (This is the specific field from your DB)
//       localStorage.setItem("userName", user.name);

//       // Save profile pic if it exists, otherwise empty string
//       localStorage.setItem(
//         "userProfilePic",
//         user.profilePicUrl || user.avatar || ""
//       );

//       // User ID for future requests
//       localStorage.setItem("userId", user._id);

//       // ============================================================
//       // 3. CRITICAL: NOTIFY HEADER TO UPDATE
//       // These lines force the Header component to re-read LocalStorage
//       // ============================================================
//       window.dispatchEvent(new Event("storage"));
//       window.dispatchEvent(new CustomEvent("authChange"));

//       // 4. NAVIGATE BASED ON ROLE
//       const role = user.type.toLowerCase();

//       if (role === "user") {
//         navigate("/user/dashboard");
//       } else if (role === "governor") {
//         navigate("/governor");
//       } else if (role === "investor") {
//         navigate("/investor");
//       } else if (role === "banker") {
//         navigate("/banker");
//       } else {
//         // Fallback if role is undefined or new
//         navigate("/");
//       }
//     } catch (err) {
//       console.error("Login Error:", err);
//       // Handle different error structures safely
//       const errorMsg =
//         err.response?.data?.message ||
//         "Login failed. Please check credentials.";
//       setMessage(errorMsg);
//     }
//   };

//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4">
//       <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl shadow-2xl p-8 w-full max-w-md text-center text-white">
//         <div className="text-2xl font-bold text-sky-400 mb-4">
//           AI DPR Analyzer
//         </div>
//         <h2 className="text-xl font-semibold mb-6">
//           Welcome! What's your email?
//         </h2>

//         <form onSubmit={handleLogin} className="flex flex-col gap-4">
//           <input
//             type="email"
//             placeholder="Email"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             required
//             className="w-full p-3 rounded-lg bg-slate-900/60 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400"
//           />

//           <div className="relative">
//             <input
//               type={showPassword ? "text" : "password"}
//               placeholder="Password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//               className="w-full p-3 rounded-lg bg-slate-900/60 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400"
//             />
//             <span
//               onClick={() => setShowPassword(!showPassword)}
//               className="absolute right-4 top-3.5 text-slate-400 cursor-pointer hover:text-sky-400 transition"
//             >
//               {showPassword ? <FaEyeSlash /> : <FaEye />}
//             </span>
//           </div>

//           <button
//             type="submit"
//             className="w-full py-3 mt-2 rounded-lg bg-gradient-to-r from-sky-400 to-blue-600 font-semibold text-white shadow-lg hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all duration-300"
//           >
//             Login
//           </button>
//         </form>

//         {message && (
//           <div className="mt-3 p-2 bg-red-500/20 border border-red-500/50 rounded-lg">
//             <p className="text-red-200 text-sm font-medium">{message}</p>
//           </div>
//         )}

//         <div className="relative my-6">
//           <div className="absolute inset-0 flex items-center">
//             <div className="w-full border-t border-slate-700"></div>
//           </div>
//           <div className="relative flex justify-center text-sm">
//             <span className="px-2 bg-slate-800 text-slate-300 rounded-full">
//               or sign in with
//             </span>
//           </div>
//         </div>

//         <div className="flex justify-center gap-4 mb-4">
//           {/* <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
//             <FaApple />
//           </button> */}
//           {/* <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
//             <FaGoogle />
//           </button> */}
//           <button className="w-full p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition flex justify-center items-center">
//             <FaGoogle />
//           </button>
//           {/* <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
//             <FaFacebookF />
//           </button> */}
//         </div>

//         <div className="text-slate-400 text-sm">
//           Don’t have an account?{" "}
//           <span
//             onClick={() => navigate("/register")}
//             className="text-sky-400 hover:underline cursor-pointer"
//           >
//             Register
//           </span>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Login;

// // import { useState, useEffect } from "react"; // 1. Import useEffect
// // import { useNavigate } from "react-router-dom";
// // import {
// //   FaApple,
// //   FaGoogle,
// //   FaFacebookF,
// //   FaEye,
// //   FaEyeSlash,
// // } from "react-icons/fa";
// // import axios from "axios";

// // const Login = () => {
// //   const [email, setEmail] = useState("");
// //   const [password, setPassword] = useState("");
// //   const [showPassword, setShowPassword] = useState(false);
// //   const [message, setMessage] = useState("");
// //   const navigate = useNavigate();

// //   const API_BASE = "http://localhost:5000/api/auth";

// //   // --- 2. USE EFFECT: CHECK EXISTING SESSION ---
// //   // This runs once when the component mounts.
// //   // If data exists and is valid (not "undefined"), it auto-redirects.
// //   useEffect(() => {
// //     const checkSession = () => {
// //       const token = localStorage.getItem("token");
// //       const userId = localStorage.getItem("userId");
// //       const userType = localStorage.getItem("userType");

// //       // Check if token exists AND is not the string "undefined" or "null"
// //       if (token && userId && userId !== "undefined" && userId !== "null") {
// //         console.log("User already logged in, redirecting...");
// //         navigateBasedOnRole(userType);
// //       }
// //     };

// //     checkSession();
// //   }, [navigate]);

// //   // --- HELPER: CENTRALIZED NAVIGATION ---
// //   const navigateBasedOnRole = (role) => {
// //     // Default to 'user' if role is missing or weird
// //     const safeRole = role ? role.toLowerCase() : "user";

// //     if (safeRole === "user") navigate("/user/dashboard");
// //     else if (safeRole === "governor") navigate("/governor");
// //     else if (safeRole === "investor") navigate("/investor");
// //     else if (safeRole === "banker") navigate("/banker");
// //     else navigate("/");
// //   };

// //   const handleLogin = async (e) => {
// //     e.preventDefault();
// //     setMessage("");

// //     try {
// //       const res = await axios.post(`${API_BASE}/login`, { email, password });
// //       console.log("Login API Response:", res.data);

// //       // --- 3. ROBUST DATA EXTRACTION ---
// //       const user = res.data?.user;
// //       const token = res.data?.token;

// //       // Safety Check: If API didn't send user or token, stop here
// //       if (!user || !token) {
// //         throw new Error("Invalid response from server (Missing User or Token)");
// //       }

// //       // --- 4. PREVENT "UNDEFINED" STORAGE ---
// //       // We use ( || "") to ensure if a field is missing, we save an empty string, not "undefined"
// //       const userId = user._id || "";
// //       const userName = user.name || "Unknown User";
// //       const userType = user.type || "user";
// //       const userPic = user.profilePicUrl || user.avatar || "";

// //       // Double check critical ID
// //       if (!userId) throw new Error("User ID is missing from database response");

// //       // Save to LocalStorage
// //       localStorage.setItem("token", token);
// //       localStorage.setItem("userId", userId);
// //       localStorage.setItem("userName", userName);
// //       localStorage.setItem("userType", userType.toLowerCase());
// //       localStorage.setItem("userProfilePic", userPic);

// //       // Notify Header
// //       window.dispatchEvent(new Event("storage"));
// //       window.dispatchEvent(new CustomEvent("authChange"));

// //       // Redirect
// //       navigateBasedOnRole(userType);

// //     } catch (err) {
// //       console.error("Login Error:", err);
// //       // Clear storage if login failed to prevent half-saved states
// //       localStorage.clear();

// //       const errorMsg = err.response?.data?.message || err.message || "Login failed.";
// //       setMessage(errorMsg);
// //     }
// //   };

// //   return (
// //     <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4">
// //       <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl shadow-2xl p-8 w-full max-w-md text-center text-white">
// //         <div className="text-2xl font-bold text-sky-400 mb-4">
// //           AI DPR Analyzer
// //         </div>
// //         <h2 className="text-xl font-semibold mb-6">
// //           Welcome! What's your email?
// //         </h2>

// //         <form onSubmit={handleLogin} className="flex flex-col gap-4">
// //           <input
// //             type="email"
// //             placeholder="Email"
// //             value={email}
// //             onChange={(e) => setEmail(e.target.value)}
// //             required
// //             className="w-full p-3 rounded-lg bg-slate-900/60 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400"
// //           />

// //           <div className="relative">
// //             <input
// //               type={showPassword ? "text" : "password"}
// //               placeholder="Password"
// //               value={password}
// //               onChange={(e) => setPassword(e.target.value)}
// //               required
// //               className="w-full p-3 rounded-lg bg-slate-900/60 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400"
// //             />
// //             <span
// //               onClick={() => setShowPassword(!showPassword)}
// //               className="absolute right-4 top-3.5 text-slate-400 cursor-pointer hover:text-sky-400 transition"
// //             >
// //               {showPassword ? <FaEyeSlash /> : <FaEye />}
// //             </span>
// //           </div>

// //           <button
// //             type="submit"
// //             className="w-full py-3 mt-2 rounded-lg bg-gradient-to-r from-sky-400 to-blue-600 font-semibold text-white shadow-lg hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all duration-300"
// //           >
// //             Login
// //           </button>
// //         </form>

// //         {message && (
// //           <div className="mt-3 p-2 bg-red-500/20 border border-red-500/50 rounded-lg">
// //             <p className="text-red-200 text-sm font-medium">{message}</p>
// //           </div>
// //         )}

// //         <div className="relative my-6">
// //           <div className="absolute inset-0 flex items-center">
// //             <div className="w-full border-t border-slate-700"></div>
// //           </div>
// //           <div className="relative flex justify-center text-sm">
// //             <span className="px-2 bg-slate-800 text-slate-300 rounded-full">or sign in with</span>
// //           </div>
// //         </div>

// //         <div className="flex justify-center gap-4 mb-4">
// //           <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
// //             <FaApple />
// //           </button>
// //           <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
// //             <FaGoogle />
// //           </button>
// //           <button className="p-3 rounded-full bg-slate-800 hover:bg-sky-500/30 text-white transition">
// //             <FaFacebookF />
// //           </button>
// //         </div>

// //         <div className="text-slate-400 text-sm">
// //           Don’t have an account?{" "}
// //           <span
// //             onClick={() => navigate("/register")}
// //             className="text-sky-400 hover:underline cursor-pointer"
// //           >
// //             Register
// //           </span>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Login;







import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Eye, EyeOff, Mail, Lock } from "lucide-react";
import axios from "axios";

// --- INLINE SVGs FOR BRAND ICONS (To avoid dependency errors) ---
const GoogleIcon = () => (
  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M23.766 12.2764C23.766 11.4607 23.6999 10.6406 23.5588 9.83807H12.24V14.4591H18.7217C18.4528 15.9494 17.5885 17.2678 16.323 18.1056V21.1039H20.19C22.4608 19.0139 23.766 15.9274 23.766 12.2764Z" fill="#4285F4" />
    <path d="M12.2401 24.0008C15.4766 24.0008 18.2059 22.9382 20.1945 21.1039L16.3275 18.1055C15.2517 18.8375 13.8627 19.252 12.2445 19.252C9.11388 19.252 6.45946 17.1399 5.50705 14.3003H1.5166V17.3912C3.55371 21.4434 7.7029 24.0008 12.2401 24.0008Z" fill="#34A853" />
    <path d="M5.50253 14.3003C5.00236 12.8199 5.00236 11.1799 5.50253 9.69951V6.60864H1.51649C-0.18551 10.0056 -0.18551 13.9945 1.51649 17.3915L5.50253 14.3003Z" fill="#FBBC05" />
    <path d="M12.2401 4.74966C13.9509 4.7232 15.6044 5.36697 16.8434 6.54867L20.2695 3.12262C18.1001 1.0855 15.2208 -0.034466 12.2401 0.000808666C7.7029 0.000808666 3.55371 2.55822 1.5166 6.60864L5.50264 9.69951C6.45064 6.86248 9.10947 4.74966 12.2401 4.74966Z" fill="#EA4335" />
  </svg>
);

const AppleIcon = () => (
  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.74 1.18 0 2.45-1.02 4.1-1.02 1.57.1 2.94.8 3.55 1.76-2.9 1.74-2.4 6.07.6 7.28-.62 1.63-1.52 3.04-2.33 4.21zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.54 4.33-3.74 4.25z"/>
  </svg>
);

const FacebookIcon = () => (
  <svg className="w-5 h-5 text-[#1877F2]" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.415 23.094 10.125 24v-8.437h-3.047v-3.49h3.047v-2.642c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953h-1.513c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.49h-2.796V24C19.585 23.094 24 18.1 24 12.073z" />
  </svg>
);

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const navigate = useNavigate();

  // Ensure this matches your backend port
  const API_BASE = "http://localhost:5000/api/auth";

  // --- 1. AUTO-REDIRECT IF ALREADY LOGGED IN ---
  useEffect(() => {
    const checkSession = () => {
      const token = localStorage.getItem("token");
      const userType = localStorage.getItem("userType");

      if (token && userType) {
        navigateBasedOnRole(userType);
      }
    };
    checkSession();
  }, [navigate]);

  // --- 2. NAVIGATION LOGIC ---
  const navigateBasedOnRole = (role) => {
    const safeRole = role ? role.toLowerCase() : "user";
    if (safeRole === "user") navigate("/user/dashboard");
    else if (safeRole === "governor") navigate("/governor");
    else if (safeRole === "investor") navigate("/investor");
    else if (safeRole === "banker") navigate("/banker");
    else navigate("/");
  };

  // --- 3. LOGIN HANDLER ---
  const handleLogin = async (e) => {
    e.preventDefault();
    setMessage("");
    setIsLoading(true);

    try {
      const res = await axios.post(`${API_BASE}/login`, { email, password });

      // Extract Data
      const user = res.data.user;
      const token = res.data.token;

      if (!user || !token) {
        throw new Error("Invalid response from server.");
      }

      // Save to LocalStorage
      localStorage.setItem("token", token);
      localStorage.setItem("userType", user.type.toLowerCase());
      localStorage.setItem("userName", user.name);
      localStorage.setItem("email", user.email);
      localStorage.setItem("userId", user._id);
      localStorage.setItem(
        "userProfilePic",
        user.profilePicUrl || user.avatar || ""
      );

      // --- CRITICAL: Notify Header to update ---
      window.dispatchEvent(new Event("storage"));
      window.dispatchEvent(new CustomEvent("authChange"));

      // Redirect
      navigateBasedOnRole(user.type);

    } catch (err) {
      console.error("Login Error:", err);
      const errorMsg =
        err.response?.data?.message ||
        "Login failed. Please check credentials.";
      setMessage(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 relative overflow-hidden px-4">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
      <div className="absolute -top-20 -left-20 w-96 h-96 bg-blue-600/20 rounded-full blur-[128px]"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-sky-600/10 rounded-full blur-[128px]"></div>

      <div className="relative w-full max-w-md bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl p-8 animate-fadeIn">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400 mb-2">
            Welcome Back
          </h2>
          <p className="text-slate-400 text-sm">
            Sign in to verify your DPRs instantly
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="flex flex-col gap-5">
          
          {/* Email Input */}
          <div className="relative group">
            <Mail className="absolute left-4 top-3.5 w-5 h-5 text-slate-500 group-focus-within:text-sky-400 transition-colors" />
            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-slate-950/50 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all"
            />
          </div>

          {/* Password Input */}
          <div className="relative group">
            <Lock className="absolute left-4 top-3.5 w-5 h-5 text-slate-500 group-focus-within:text-sky-400 transition-colors" />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full pl-11 pr-12 py-3 rounded-xl bg-slate-950/50 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-3.5 text-slate-500 hover:text-sky-400 transition-colors focus:outline-none"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          {/* Error Message */}
          {message && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-sm text-center">
              {message}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 text-white font-bold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? "Signing In..." : "Login"}
          </button>
        </form>

        {/* Divider */}
        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="px-3 bg-slate-900 text-slate-500">or continue with</span>
          </div>
        </div>

        {/* Social Icons */}
        <div className="flex justify-center gap-4 mb-8">
          <button className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 hover:border-sky-500/50 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center justify-center">
            <GoogleIcon />
          </button>
          <button className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 hover:border-sky-500/50 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center justify-center">
            <AppleIcon />
          </button>
          <button className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 hover:border-sky-500/50 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center justify-center">
            <FacebookIcon />
          </button>
        </div>

        {/* Register Link */}
        <div className="text-center text-slate-400 text-sm">
          Don’t have an account?{" "}
          <Link
            to="/register"
            className="text-sky-400 font-semibold hover:text-sky-300 hover:underline transition-colors"
          >
            Register Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;