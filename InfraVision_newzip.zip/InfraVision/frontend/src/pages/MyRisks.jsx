import { useEffect, useState } from "react";

export default function MyRisks() {
  const [risks, setRisks] = useState([]);

  useEffect(() => {
    fetch("/api/dpr-risk/my", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`
      }
    })
      .then(res => res.json())
      .then(setRisks);
  }, []);

  return (
    <div>
      <h2>My DPR Risk Reports</h2>
      {risks.map(r => (
        <div key={r._id}>
          <h4>{r.fileName}</h4>
          <p>Risk: {r.riskLevel}</p>
        </div>
      ))}
    </div>
  );
}
