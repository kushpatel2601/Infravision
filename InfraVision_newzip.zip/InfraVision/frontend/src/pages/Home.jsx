// import { useEffect } from "react";
// import { Link } from "react-router-dom";
// import { motion } from "framer-motion";

// const Home = () => {
//   useEffect(() => {
//     // Auto logout on visiting Home page
//     localStorage.removeItem("token");
//     localStorage.removeItem("userType");
//   }, []);

//   return (
//     <div className="min-h-[calc(100vh-80px)] flex flex-col justify-center items-center text-center px-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden relative">
//       {/* Background subtle gradient or blur effect */}
//       <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-20 pointer-events-none"></div>

//       {/* Hero Title */}
//       <motion.h1
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ duration: 0.8 }}
//         className="text-3xl md:text-5xl font-bold text-slate-50 mb-4"
//       >
//         AI-Powered DPR Analysis & Risk Prediction
//       </motion.h1>

//       {/* Description */}
//       <motion.p
//         initial={{ opacity: 0 }}
//         animate={{ opacity: 1 }}
//         transition={{ delay: 0.4, duration: 0.8 }}
//         className="max-w-2xl text-slate-300 text-base md:text-lg leading-relaxed mb-8"
//       >
//         Upload Detailed Project Reports (DPRs) and get automated insights, risk
//         evaluation, and data-driven recommendations to support smarter, faster,
//         and safer decision-making.
//       </motion.p>

//       {/* Buttons */}
//       <motion.div
//         initial={{ opacity: 0 }}
//         animate={{ opacity: 1 }}
//         transition={{ delay: 0.8, duration: 0.8 }}
//         className="flex gap-4 flex-wrap justify-center"
//       >
//         <Link
//           to="/login"
//           className="px-6 py-3 rounded-xl font-semibold text-white text-lg bg-gradient-to-r from-sky-400 to-blue-600 shadow-lg hover:shadow-blue-500/40 hover:-translate-y-1 transition-all duration-300"
//         >
//           Get Started
//         </Link>
//       </motion.div>

//       {/* Features */}
//       <motion.div
//         initial={{ opacity: 0, y: 20 }}
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ delay: 1.2, duration: 0.8 }}
//         className="flex flex-wrap justify-center gap-8 mt-20 max-w-6xl w-full"
//       >
//         {/* Card 1 */}
//         <div className="bg-white/10 backdrop-blur-md border border-white/20 flex-1 min-w-[250px] max-w-[300px] rounded-2xl p-8 text-center text-slate-100 shadow-lg hover:-translate-y-2 hover:shadow-sky-500/30 transition-all duration-300">
//           <h3 className="text-sky-400 text-xl font-semibold mb-3">
//             Automated Risk Analysis
//           </h3>
//           <p className="text-slate-300 text-sm leading-relaxed">
//             Identify potential project risks using AI algorithms to reduce
//             delays and cost overruns.
//           </p>
//         </div>

//         {/* Card 2 */}
//         <div className="bg-white/10 backdrop-blur-md border border-white/20 flex-1 min-w-[250px] max-w-[300px] rounded-2xl p-8 text-center text-slate-100 shadow-lg hover:-translate-y-2 hover:shadow-sky-500/30 transition-all duration-300">
//           <h3 className="text-sky-400 text-xl font-semibold mb-3">
//             Smart Insights
//           </h3>
//           <p className="text-slate-300 text-sm leading-relaxed">
//             Receive detailed suggestions and recommendations to optimize project
//             planning.
//           </p>
//         </div>

//         {/* Card 3 */}
//         <div className="bg-white/10 backdrop-blur-md border border-white/20 flex-1 min-w-[250px] max-w-[300px] rounded-2xl p-8 text-center text-slate-100 shadow-lg hover:-translate-y-2 hover:shadow-sky-500/30 transition-all duration-300">
//           <h3 className="text-sky-400 text-xl font-semibold mb-3">
//             Data-Driven Decisions
//           </h3>
//           <p className="text-slate-300 text-sm leading-relaxed">
//             Leverage AI evaluations to make informed decisions quickly and
//             accurately.
//           </p>
//         </div>
//       </motion.div>

//     </div>
//   );
// };

// export default Home;




import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ShieldAlert,
  ClipboardCheck,
  CircleDollarSign,
  History,
  ScanText,
  BrainCircuit,
  Zap,
  TrendingUp,
  CheckCircle2,
  Mail,
  Phone,
  MapPin,
  Send,
  ArrowRight
} from "lucide-react";

const Home = () => {
  useEffect(() => {
    // Auto logout on visiting Home page
    localStorage.removeItem("token");
    localStorage.removeItem("userType");
  }, []);

  // Form State
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // --- DATA SECTIONS ---

  // 1. Core Features
  const features = [
    {
      title: "Automated Risk Scoring",
      desc: "Instant AI-generated risk scores (0-100) analyzing financial, technical, and operational parameters.",
      color: "text-sky-400",
      bgColor: "bg-sky-400/10",
      icon: ShieldAlert,
    },
    {
      title: "Regulatory Compliance",
      desc: "Auto-verify DPR adherence to CPWD norms, environmental guidelines, and government statutory requirements.",
      color: "text-emerald-400",
      bgColor: "bg-emerald-400/10",
      icon: ClipboardCheck,
    },
    {
      title: "Cost Anomaly Detection",
      desc: "Identify inflated estimates or budget discrepancies by comparing unit rates with historical market data.",
      color: "text-rose-400",
      bgColor: "bg-rose-400/10",
      icon: CircleDollarSign,
    },
    {
      title: "Historical Benchmarking",
      desc: "Compare current project metrics against a database of past projects to predict timeline slippages.",
      color: "text-purple-400",
      bgColor: "bg-purple-400/10",
      icon: History,
    },
    {
      title: "Smart Document Parsing",
      desc: "Extract structured data from unstructured PDF/Word DPRs using NLP to feed the analysis engine.",
      color: "text-amber-400",
      bgColor: "bg-amber-400/10",
      icon: ScanText,
    },
    {
      title: "Decision Support System",
      desc: "Actionable recommendations for approval authorities to approve, reject, or request modifications.",
      color: "text-blue-300",
      bgColor: "bg-blue-300/10",
      icon: BrainCircuit,
    },
  ];

  // 2. Impact Metrics (Why Choose Us)
  const stats = [
    { label: "Processing Speed", value: "95%", suffix: "Faster", icon: Zap, desc: "Compared to manual scrutiny" },
    { label: "Cost Optimization", value: "15%", suffix: "Avg. Savings", icon: TrendingUp, desc: "By detecting inflation" },
    { label: "Accuracy Rate", value: "99.8%", suffix: "Precision", icon: CheckCircle2, desc: "In compliance checks" },
  ];

  // 3. Workflow Steps (About Section)
  const workflow = [
    { id: 1, title: "Upload DPR", desc: "Upload PDF/Excel files securely." },
    { id: 2, title: "AI Extraction", desc: "OCR & NLP extract key data points." },
    { id: 3, title: "Risk Analysis", desc: "Engine checks norms & costs." },
    { id: 4, title: "Final Report", desc: "Download detailed risk assessment." },
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-sky-500/30">
      
      {/* --- HERO SECTION --- */}
      <div className="relative pt-20 pb-32 flex flex-col items-center text-center px-6 overflow-hidden">
        {/* Background Noise & Gradient */}
        <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-20 pointer-events-none"></div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-blue-600/20 blur-[120px] rounded-full pointer-events-none"></div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 max-w-4xl"
        >
          <span className="inline-block py-1 px-3 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300 text-sm font-medium mb-6">
            ✨ AI-Powered Government Tech
          </span>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8">
            DPR Analysis & <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-blue-500 to-purple-600">
              Risk Prediction
            </span>
          </h1>
          <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Revolutionizing public infrastructure planning. Upload Detailed Project Reports and let our AI predict risks, validate costs, and ensure compliance in seconds.
          </p>
          
          <div className="flex gap-4 justify-center">
            <Link to="/login" className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold transition-all shadow-lg shadow-blue-600/25 flex items-center gap-2">
              Start Analysis <ArrowRight size={20} />
            </Link>
            <button className="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-semibold transition-all">
              Watch Demo
            </button>
          </div>
        </motion.div>
      </div>

      {/* --- STATS SECTION --- */}
      <section className="py-20 bg-slate-900/50 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="flex flex-col items-center text-center p-6 bg-slate-800/50 rounded-2xl border border-white/5"
            >
              <stat.icon className="w-10 h-10 text-sky-500 mb-4" />
              <div className="text-4xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-sky-400 font-medium text-lg mb-2">{stat.suffix}</div>
              <p className="text-slate-400 text-sm">{stat.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* --- FEATURES GRID --- */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Detection Capabilities</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Our engine uses advanced NLP and regression models to scan hundreds of pages instantly.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-800/40 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/60 transition-all duration-300 hover:border-sky-500/30 group"
              >
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${feature.bgColor} mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className={`w-8 h-8 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-bold text-slate-100 mb-3">{feature.title}</h3>
                <p className="text-slate-400 leading-relaxed text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- ABOUT / WORKFLOW SECTION --- */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center gap-16">
          {/* Left Text */}
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Streamlining Government <br/>
              <span className="text-blue-500">Infrastructure Approval</span>
            </h2>
            <p className="text-slate-400 text-lg mb-8 leading-relaxed">
              Detailed Project Reports (DPRs) are the backbone of development, yet 40% face rejection due to compliance errors. Our system bridges the gap between technical planning and administrative approval.
            </p>
            
            <div className="space-y-6">
              {workflow.map((step) => (
                <div key={step.id} className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-sm font-bold shrink-0 mt-1">
                    {step.id}
                  </div>
                  <div>
                    <h4 className="font-bold text-lg text-slate-200">{step.title}</h4>
                    <p className="text-slate-500 text-sm">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Visual (Abstract representation) */}
          <div className="lg:w-1/2 w-full">
            <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-slate-700 shadow-2xl">
              <div className="absolute top-4 right-4 flex gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/20"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/20"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/20"></div>
              </div>
              <div className="space-y-4 mt-4">
                 {/* Fake UI Elements */}
                 <div className="h-4 bg-slate-700 rounded w-3/4 animate-pulse"></div>
                 <div className="h-4 bg-slate-700 rounded w-1/2 animate-pulse"></div>
                 <div className="h-32 bg-slate-800 rounded border border-slate-700 mt-6 flex items-center justify-center flex-col gap-2">
                    <ScanText className="text-blue-500 animate-bounce" size={32} />
                    <span className="text-xs text-blue-400 font-mono">Analyzing DPR...</span>
                 </div>
                 <div className="flex gap-4 mt-4">
                   <div className="flex-1 h-20 bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
                      <div className="text-emerald-400 text-xs font-bold">Compliance</div>
                      <div className="text-2xl font-bold text-emerald-300">98%</div>
                   </div>
                   <div className="flex-1 h-20 bg-rose-500/10 border border-rose-500/20 rounded-lg p-3">
                      <div className="text-rose-400 text-xs font-bold">Risks Found</div>
                      <div className="text-2xl font-bold text-rose-300">3</div>
                   </div>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- CONTACT SECTION --- */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-blue-600/5 -skew-y-3 transform origin-left"></div>
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="bg-slate-800/80 backdrop-blur-xl rounded-3xl p-8 md:p-16 border border-white/10 shadow-2xl flex flex-col md:flex-row gap-12">
            
            {/* Contact Info */}
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
              <p className="text-slate-400 mb-8">
                Interested in deploying this system for your department? Contact our technical team for a pilot demonstration.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4 text-slate-300">
                  <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-blue-400">
                    <Mail size={20} />
                  </div>
                  <span>support@dpr-ai.gov.in</span>
                </div>
                <div className="flex items-center gap-4 text-slate-300">
                  <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-blue-400">
                    <Phone size={20} />
                  </div>
                  <span>+91 11-2301-XXXX</span>
                </div>
                <div className="flex items-center gap-4 text-slate-300">
                  <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-blue-400">
                    <MapPin size={20} />
                  </div>
                  <span>Civil Lines, New Delhi</span>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <form className="md:w-1/2 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Full Name</label>
                <input 
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors" 
                  placeholder="Officer Name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Official Email</label>
                <input 
                  type="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors" 
                  placeholder="name@dept.gov.in"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Message</label>
                <textarea 
                  rows="4"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors" 
                  placeholder="Describe your requirements..."
                ></textarea>
              </div>
              <button 
                type="submit" 
                onClick={(e) => e.preventDefault()}
                className="w-full bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-500 hover:to-sky-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-500/25 transition-all flex items-center justify-center gap-2"
              >
                Send Request <Send size={18} />
              </button>
            </form>

          </div>
        </div>
      </section>

      {/* --- FOOTER --- */}
      {/* <footer className="bg-slate-950 py-12 border-t border-slate-800 text-center md:text-left">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold text-white mb-4">DPR-AI Analysis</h3>
            <p className="text-slate-500 max-w-sm">
              Empowering infrastructure development with Artificial Intelligence. 
              Secure, Fast, and Accurate.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-slate-500 text-sm">
              <li className="hover:text-blue-400 cursor-pointer">Home</li>
              <li className="hover:text-blue-400 cursor-pointer">About System</li>
              <li className="hover:text-blue-400 cursor-pointer">Case Studies</li>
              <li className="hover:text-blue-400 cursor-pointer">Login</li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-slate-500 text-sm">
              <li className="hover:text-blue-400 cursor-pointer">Privacy Policy</li>
              <li className="hover:text-blue-400 cursor-pointer">Terms of Service</li>
              <li className="hover:text-blue-400 cursor-pointer">Disclaimer</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-12 pt-8 border-t border-slate-800 text-center text-slate-600 text-sm">
          &copy; {new Date().getFullYear()} AI-DPR System. All rights reserved.
        </div>
      </footer> */}

    </div>
  );
};

export default Home;