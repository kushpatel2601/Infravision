import React, { useState, useEffect } from "react";
import {
  User,
  Mail,
  Briefcase,
  MapPin,
  Calendar,
  Edit3,
  Camera,
  Shield,
  Activity,
  FileText,
  X,
} from "lucide-react";
 
const Profile = () => {
  const [user, setUser] = useState({
    name: "",
    type: "",
    email: "", // Will be filled from DB
    avatar: "",
    joinDate: "Nov 2023",
  });
 
  // State for Modal and Form Data
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ name: "", email: "" });
 
  useEffect(() => {
    const fetchProfileData = async () => {
      // 1. Get basic info from Local Storage (Fast load)
      const localName = localStorage.getItem("userName") || "Guest User";
      const localType = localStorage.getItem("userType") || "User";
      const localAvatar = localStorage.getItem("userProfilePic");
      const localEmail = localStorage.getItem("email"); // Might be null initially
 
      setUser((prev) => ({
        ...prev,
        name: localName,
        type: localType,
        avatar: localAvatar,
        email: localEmail,
      }));
 
      // 2. Fetch fresh details from Database (to get Email)
      const token = localStorage.getItem("token");
      const userId = localStorage.getItem("userId");
 
      if (token && userId) {
        try {
          // NOTE: Ensure this endpoint exists in your backend
          const response = await fetch(
            `http://localhost:5000/api/auth/user/${userId}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
 
          if (response.ok) {
            const data = await response.json();
            // Handle different API response structures (data.user or data.data or just data)
            const userData = data.user || data.data || data;
 
            setUser((prev) => ({
              ...prev,
              name: userData.name || prev.name,
              email: userData.email || prev.email,
              type: userData.type || prev.type,
              avatar: userData.profilePicUrl || userData.avatar || prev.avatar,
            }));
 
            // Sync email to local storage for next time
            if (userData.email) {
              localStorage.setItem("userEmail", userData.email);
            }
          }
        } catch (error) {
          console.error("Error fetching fresh profile:", error);
        }
      }
    };
 
    fetchProfileData();
  }, []);
 
  // Open Modal and populate current data
  const handleEditClick = () => {
    setEditForm({ name: user.name, email: user.email });
    setIsEditing(true);
  };
 
  // Handle Input Change
  const handleInputChange = (e) => {
    setEditForm({ ...editForm, [e.target.name]: e.target.value });
  };
 
  // Save Changes to Database
  const handleSave = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("You are not logged in!");
        return;
      }
 
      // 1. Send API Request
      const response = await fetch(
        "http://localhost:5000/api/auth/update-profile",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: editForm.name,
            email: editForm.email,
          }),
        }
      );
 
      const data = await response.json();
 
      if (!response.ok) {
        throw new Error(data.message || "Failed to update profile");
      }
 
      // 2. Update UI State
      setUser((prev) => ({
        ...prev,
        name: data.user.name,
        email: data.user.email,
      }));
 
      // 3. Update Local Storage
      localStorage.setItem("userName", data.user.name);
      localStorage.setItem("email", data.user.email);
 
      // 4. Close Modal & Notify
      setIsEditing(false);
      window.dispatchEvent(new Event("storage")); // Update header
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      alert(error.message);
    }
  };
 
  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden font-sans text-slate-100 p-6 md:p-10">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[128px] pointer-events-none"></div>
 
      <div className="max-w-5xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400 mb-2">
            My Profile
          </h1>
          <p className="text-slate-400">
            Manage your personal information and account status.
          </p>
        </div>
 
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Identity Card */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-6 flex flex-col items-center text-center shadow-xl">
              <div className="relative mb-4 group cursor-pointer">
                <div className="w-32 h-32 rounded-full border-4 border-slate-800 overflow-hidden bg-slate-950 flex items-center justify-center">
                  {user.avatar ? (
                    <img
                      src={user.avatar}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User size={48} className="text-slate-600" />
                  )}
                </div>
                <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Camera className="text-white w-8 h-8" />
                </div>
              </div>
 
              <h2 className="text-xl font-bold text-white mb-1">{user.name}</h2>
              <span className="px-3 py-1 rounded-full bg-sky-500/10 text-sky-400 text-xs font-bold border border-sky-500/20 uppercase tracking-wide">
                {user.type}
              </span>
 
              <div className="mt-6 w-full space-y-4">
                <div className="flex items-center gap-3 text-slate-400 text-sm">
                  <Mail size={16} className="text-slate-500" />
                  <span className="truncate max-w-[200px]" title={user.email}>
                    {user.email}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-sm">
                  <Briefcase size={16} className="text-slate-500" />
                  <span>InfraVision Member</span>
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-sm">
                  <Calendar size={16} className="text-slate-500" />
                  <span>Joined {user.joinDate}</span>
                </div>
              </div>
 
              <button
                onClick={handleEditClick}
                className="mt-8 w-full py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 font-medium transition-all text-sm flex items-center justify-center gap-2"
              >
                <Edit3 size={16} /> Edit Profile
              </button>
            </div>
 
            {/* Verification Status */}
            <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-slate-300 mb-4 flex items-center gap-2">
                <Shield size={16} className="text-emerald-500" /> Verification
                Status
              </h3>
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-sm">Email Verified</span>
                <span className="text-emerald-400 text-xs font-bold">YES</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full mb-4">
                <div className="bg-emerald-500 h-1.5 rounded-full w-full"></div>
              </div>
 
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-sm">KYC Complete</span>
                <span className="text-amber-400 text-xs font-bold">
                  PENDING
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full">
                <div className="bg-amber-500 h-1.5 rounded-full w-2/3"></div>
              </div>
            </div>
          </div>
 
          {/* Right Column: Stats & Activity */}
          <div className="lg:col-span-2 space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-slate-400 text-xs font-bold uppercase">
                    Projects
                  </span>
                  <FileText size={18} className="text-blue-500" />
                </div>
                <div className="text-2xl font-bold text-white">12</div>
                <div className="text-xs text-emerald-400 mt-1">
                  +2 this month
                </div>
              </div>
              <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-slate-400 text-xs font-bold uppercase">
                    Risk Checks
                  </span>
                  <Activity size={18} className="text-purple-500" />
                </div>
                <div className="text-2xl font-bold text-white">45</div>
                <div className="text-xs text-emerald-400 mt-1">
                  98% Success rate
                </div>
              </div>
              <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-slate-400 text-xs font-bold uppercase">
                    Location
                  </span>
                  <MapPin size={18} className="text-rose-500" />
                </div>
                <div className="text-2xl font-bold text-white">IND</div>
                <div className="text-xs text-slate-500 mt-1">
                  Primary Region
                </div>
              </div>
            </div>
 
            {/* Recent Activity */}
            <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-8">
              <h3 className="text-lg font-bold text-white mb-6">
                Recent Activity
              </h3>
              <div className="space-y-6">
                {[
                  {
                    title: "Uploaded 'Highway_DPR_V2.pdf'",
                    time: "2 hours ago",
                    type: "upload",
                  },
                  {
                    title: "Risk Analysis completed for 'Assam Bridge'",
                    time: "5 hours ago",
                    type: "analysis",
                  },
                  {
                    title: "Updated profile information",
                    time: "1 day ago",
                    type: "account",
                  },
                  {
                    title: "Login from new device (Macbook Pro)",
                    time: "2 days ago",
                    type: "security",
                  },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start gap-4 group">
                    <div className="relative mt-1.5">
                      <div className="w-2 h-2 rounded-full bg-slate-600 group-hover:bg-sky-500 transition-colors"></div>
                      {idx !== 3 && (
                        <div className="absolute top-2 left-1 w-px h-10 bg-slate-800 -ml-[0.5px]"></div>
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-slate-300 font-medium group-hover:text-sky-400 transition-colors">
                        {item.title}
                      </p>
                      <span className="text-xs text-slate-500">
                        {item.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
 
        {/* --- EDIT PROFILE MODAL --- */}
        {isEditing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl relative overflow-hidden">
              {/* Modal Header */}
              <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/50">
                <h3 className="text-lg font-bold text-white">Edit Profile</h3>
                <button
                  onClick={() => setIsEditing(false)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
 
              {/* Modal Body */}
              <div className="p-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">
                    Full Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={editForm.name}
                    onChange={handleInputChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all"
                    placeholder="Enter full name"
                  />
                </div>
 
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">
                    Email Address
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={editForm.email}
                    onChange={handleInputChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none transition-all"
                    placeholder="Enter email address"
                  />
                </div>
 
                <div className="pt-2">
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                    <Shield size={12} />
                    Your role ({user.type}) cannot be changed here.
                  </p>
                </div>
              </div>
 
              {/* Modal Footer */}
              <div className="p-6 border-t border-slate-800 bg-slate-900/50 flex justify-end gap-3">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-lg text-sm font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-6 py-2 rounded-lg text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-500/20 transition-all"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
 
export default Profile;
 