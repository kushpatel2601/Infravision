import React from 'react'

const BankerDashboard = () => {
  return (
    <div>
      Hello Banker Dashboard
    </div>
  )
}

export default BankerDashboard
