import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Settings as SettingsIcon, Bell, Lock, User,
  Globe, LogOut, Check, ChevronRight, Moon, Shield
} from "lucide-react";
 
const Settings = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("general");
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    reports: true
  });
 
  const toggleNotification = (key) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
  };
 
  const handleLogout = () => {
    // 1. Clear all session data
    localStorage.clear();
 
    // 2. Notify other components (like Header) that auth state changed
    window.dispatchEvent(new Event("storage"));
    window.dispatchEvent(new CustomEvent("authChange"));
 
    // 3. Redirect to login page
    navigate("/login");
  };
 
  const tabs = [
    { id: "general", label: "General", icon: User },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "security", label: "Security", icon: Lock },
    { id: "preferences", label: "Preferences", icon: Globe },
  ];
 
  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden font-sans text-slate-100 p-6 md:p-10">
     
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('/noise.svg')] opacity-10 pointer-events-none"></div>
     
      <div className="max-w-6xl mx-auto relative z-10">
       
        {/* Header */}
        <div className="mb-10 flex items-center gap-3">
          <div className="p-2 bg-slate-800 rounded-lg">
            <SettingsIcon className="w-6 h-6 text-slate-200" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Settings</h1>
            <p className="text-slate-400 text-sm">Manage your workspace preferences</p>
          </div>
        </div>
 
        <div className="flex flex-col lg:flex-row gap-8">
         
          {/* Sidebar Navigation */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-2 sticky top-24">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? "bg-blue-600 text-white shadow-lg shadow-blue-900/20"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                  }`}
                >
                  <tab.icon size={18} />
                  {tab.label}
                </button>
              ))}
            </div>
           
            <div className="mt-6 px-4">
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-rose-400 hover:text-rose-300 text-sm font-medium transition-colors w-full"
              >
                <LogOut size={16} /> Sign out
              </button>
            </div>
          </div>
 
          {/* Content Area */}
          <div className="flex-1">
            <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 min-h-[500px]">
             
              {/* --- GENERAL TAB --- */}
              {activeTab === "general" && (
                <div className="space-y-8 animate-fadeIn">
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1">Profile Information</h2>
                    <p className="text-slate-400 text-sm">Update your public profile details.</p>
                  </div>
                 
                  <div className="space-y-5 max-w-lg">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase">First Name</label>
                        <input type="text" defaultValue="Arjun" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase">Last Name</label>
                        <input type="text" defaultValue="Verma" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors" />
                      </div>
                    </div>
                   
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Email Address</label>
                      <input type="email" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors" />
                    </div>
 
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Bio / Department</label>
                      <textarea rows="3" defaultValue="Senior Analyst, MDoNER Infrastructure Division." className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors"></textarea>
                    </div>
 
                    <div className="pt-4">
                      <button className="bg-sky-500 hover:bg-sky-400 text-white px-6 py-2.5 rounded-lg font-bold text-sm transition-colors shadow-lg shadow-sky-900/20">Save Changes</button>
                    </div>
                  </div>
                </div>
              )}
 
              {/* --- NOTIFICATIONS TAB --- */}
              {activeTab === "notifications" && (
                <div className="space-y-8 animate-fadeIn">
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1">Notification Preferences</h2>
                    <p className="text-slate-400 text-sm">Choose how you want to be updated.</p>
                  </div>
 
                  <div className="space-y-6 max-w-2xl">
                    <div className="flex items-center justify-between p-4 bg-slate-950/50 border border-slate-800 rounded-xl">
                      <div>
                        <h3 className="font-semibold text-slate-200">Email Alerts</h3>
                        <p className="text-xs text-slate-500">Receive reports and analysis summaries via email.</p>
                      </div>
                      <button
                        onClick={() => toggleNotification('email')}
                        className={`w-12 h-6 rounded-full transition-colors relative ${notifications.email ? 'bg-sky-500' : 'bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${notifications.email ? 'left-7' : 'left-1'}`}></div>
                      </button>
                    </div>
 
                    <div className="flex items-center justify-between p-4 bg-slate-950/50 border border-slate-800 rounded-xl">
                      <div>
                        <h3 className="font-semibold text-slate-200">Push Notifications</h3>
                        <p className="text-xs text-slate-500">Get browser alerts when analysis is complete.</p>
                      </div>
                      <button
                        onClick={() => toggleNotification('push')}
                        className={`w-12 h-6 rounded-full transition-colors relative ${notifications.push ? 'bg-sky-500' : 'bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${notifications.push ? 'left-7' : 'left-1'}`}></div>
                      </button>
                    </div>
 
                    <div className="flex items-center justify-between p-4 bg-slate-950/50 border border-slate-800 rounded-xl">
                      <div>
                        <h3 className="font-semibold text-slate-200">Weekly Digest</h3>
                        <p className="text-xs text-slate-500">A weekly summary of all processed tenders.</p>
                      </div>
                      <button
                        onClick={() => toggleNotification('reports')}
                        className={`w-12 h-6 rounded-full transition-colors relative ${notifications.reports ? 'bg-sky-500' : 'bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${notifications.reports ? 'left-7' : 'left-1'}`}></div>
                      </button>
                    </div>
                  </div>
                </div>
              )}
 
              {/* --- SECURITY TAB --- */}
              {activeTab === "security" && (
                <div className="space-y-8 animate-fadeIn">
                   <div>
                    <h2 className="text-xl font-bold text-white mb-1">Security Settings</h2>
                    <p className="text-slate-400 text-sm">Manage password and security keys.</p>
                  </div>
 
                  <div className="max-w-lg space-y-6">
                    <div className="space-y-4 pb-6 border-b border-slate-800">
                      <h3 className="text-sm font-bold text-slate-300 uppercase">Change Password</h3>
                      <input type="password" placeholder="Current Password" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors" />
                      <input type="password" placeholder="New Password" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none transition-colors" />
                      <button className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">Update Password</button>
                    </div>
 
                    <div className="pt-2">
                       <h3 className="text-sm font-bold text-rose-400 uppercase mb-2">Danger Zone</h3>
                       <div className="p-4 border border-rose-900/30 bg-rose-950/10 rounded-xl flex items-center justify-between">
                          <div>
                            <p className="text-rose-200 font-semibold text-sm">Delete Account</p>
                            <p className="text-rose-400/60 text-xs">This action cannot be undone.</p>
                          </div>
                          <button
                            onClick={handleLogout} // Re-using logout for delete account simulation
                            className="text-rose-400 hover:text-rose-300 text-sm font-bold border border-rose-900/50 px-3 py-1.5 rounded-lg hover:bg-rose-950/30 transition-colors"
                          >
                            Delete
                          </button>
                       </div>
                    </div>
                  </div>
                </div>
              )}
 
               {/* --- PREFERENCES TAB --- */}
               {activeTab === "preferences" && (
                <div className="space-y-8 animate-fadeIn">
                   <div>
                    <h2 className="text-xl font-bold text-white mb-1">Global Preferences</h2>
                    <p className="text-slate-400 text-sm">Customize your viewing experience.</p>
                  </div>
 
                  <div className="max-w-lg space-y-6">
                    <div className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-3">
                         <div className="p-2 bg-slate-800 rounded-lg"><Moon size={18} /></div>
                         <span className="text-slate-200">Dark Mode</span>
                      </div>
                      <span className="text-xs font-bold bg-slate-800 px-2 py-1 rounded text-slate-400">ALWAYS ON</span>
                    </div>
 
                    <div className="space-y-2">
                       <label className="text-xs font-bold text-slate-500 uppercase">Language</label>
                       <select className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-200 focus:border-sky-500 focus:outline-none">
                          <option>English (United Kingdom)</option>
                          <option>Hindi</option>
                          <option>Assamese</option>
                       </select>
                    </div>
                  </div>
                </div>
              )}
 
            </div>
          </div>
        </div>
 
      </div>
    </div>
  );
};
 
export default Settings;