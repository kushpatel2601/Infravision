import React from 'react';
import { MapPin, Filter } from 'lucide-react';

const MapModule = ({ count }) => (
  <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl h-full flex flex-col">
    <div className="flex justify-between items-center mb-6">
      <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
        <MapPin className="w-5 h-5 text-purple-400" />
        Regional Distribution
      </h3>
      <button className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 transition-colors">
        <Filter className="w-4 h-4" />
      </button>
    </div>
   
    <div className="flex-1 bg-slate-950/50 rounded-xl border-2 border-dashed border-slate-800 flex flex-col items-center justify-center group hover:border-slate-700 transition-colors cursor-pointer relative overflow-hidden">
      {/* Abstract Map Background Effect */}
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/50 via-slate-950 to-slate-950"></div>
     
      <div className="relative z-10 text-center p-6">
        <div className="w-16 h-16 bg-slate-800/80 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-900/20 group-hover:scale-110 transition-transform">
          <MapPin size={32} className="text-purple-400" />
        </div>
        <h4 className="text-slate-200 font-semibold mb-1">Interactive Map Module</h4>
        <p className="text-slate-500 text-sm">Visualizing {count} projects across<br/>North East Region</p>
      </div>
    </div>
  </div>
);

export default MapModule;