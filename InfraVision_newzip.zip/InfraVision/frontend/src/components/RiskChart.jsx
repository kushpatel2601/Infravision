import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Activity } from 'lucide-react';

const RiskChart = ({ data }) => {
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl">
          <p className="text-slate-200 font-bold">{payload[0].name}</p>
          <p className="text-sky-400 text-sm">{payload[0].value} Projects</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl h-full flex flex-col">
      <h3 className="text-lg font-bold text-slate-100 mb-6 flex items-center gap-2">
        <Activity className="w-5 h-5 text-sky-400" />
        AI Risk Classification
      </h3>
      <div className="flex-1 min-h-[250px] relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={70}
              outerRadius={90}
              paddingAngle={5}
              dataKey="value"
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend
              verticalAlign="bottom"
              height={36}
              iconType="circle"
              formatter={(value) => <span className="text-slate-400 text-sm ml-1">{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
        {/* Center Text Overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none pb-8">
           <div className="text-center">
             <span className="text-2xl font-bold text-slate-100">{data.reduce((a,b) => a + b.value, 0)}</span>
             <p className="text-xs text-slate-500">Total</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default RiskChart;