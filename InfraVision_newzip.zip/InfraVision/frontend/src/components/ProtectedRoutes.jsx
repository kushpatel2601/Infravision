import { Navigate } from "react-router-dom";
import { getToken, getUserType } from "../utils/auth";
import { isTokenExpired } from "../utils/checkToken";
import PropTypes from "prop-types";

const ProtectedRoute = ({ children, allowedRole }) => {
  const token = getToken();
  const userType = getUserType();

  if (!token || isTokenExpired(token)) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRole && userType !== allowedRole) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

ProtectedRoute.propTypes = {
  children: PropTypes.node.isRequired,
  allowedRole: PropTypes.string,
};

export default ProtectedRoute;
