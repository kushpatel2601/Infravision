import React from 'react';

const StatCard = ({ title, value, icon, change, alert, subtext }) => (
  <div className={`relative overflow-hidden p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
    alert
      ? 'bg-rose-950/20 border-rose-500/30'
      : 'bg-slate-900/60 border-slate-800 hover:border-sky-500/30'
  }`}>
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-xl ${
        alert ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-800 text-sky-400'
      }`}>
        {icon}
      </div>
      <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
        alert
          ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
          : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      }`}>
        {change}
      </span>
    </div>
    <h3 className="text-3xl font-bold text-slate-100 mb-1">{value}</h3>
    <p className="text-sm text-slate-400 font-medium">{title}</p>
    {subtext && <p className="text-xs text-slate-500 mt-2">{subtext}</p>}
  </div>
);

export default StatCard;