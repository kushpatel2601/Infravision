// import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from 'react-icons/fa';

// const Footer = () => {
//   return (
//     <footer className="w-full bg-[#212A3E] text-[#F1F6F9] py-12 pb-4 px-8 font-poppins">
//       <div className="flex flex-wrap justify-between gap-8 max-w-6xl mx-auto">
        
//         {/* About Section */}
//         <div className="flex-1 min-w-[250px]">
//           <h3 className="text-lg font-semibold mb-3 text-[#9BA4B5]">InfraVision</h3>
//           <p className="text-sm leading-relaxed">
//             An AI-powered system to analyze Detailed Project Reports, predict risks,
//             and provide actionable insights for smarter decision-making.
//           </p>
//         </div>

//         {/* Quick Links */}
//         <div className="flex-1 min-w-[180px]">
//           <h4 className="text-base font-semibold mb-3 text-[#9BA4B5]">Quick Links</h4>
//           <ul className="space-y-2">
//             <li><a href="/" className="text-sm hover:text-[#9BA4B5] transition-colors">Home</a></li>
//             <li><a href="/dashboard" className="text-sm hover:text-[#9BA4B5] transition-colors">Dashboard</a></li>
//             <li><a href="/upload" className="text-sm hover:text-[#9BA4B5] transition-colors">Upload DPR</a></li>
//             <li><a href="/reports" className="text-sm hover:text-[#9BA4B5] transition-colors">Reports</a></li>
//             <li><a href="/contact" className="text-sm hover:text-[#9BA4B5] transition-colors">Contact</a></li>
//           </ul>
//         </div>

//         {/* Contact Section */}
//         <div className="flex-1 min-w-[200px]">
//           <h4 className="text-base font-semibold mb-3 text-[#9BA4B5]">Contact Us</h4>
//           <p className="text-sm">Email: <span className="hover:text-[#9BA4B5]">support@infravision.com</span></p>
//           <p className="text-sm">Phone: +91 98765 43210</p>
//           <p className="text-sm">Address: 123 AI Tech Street, Baroda, India</p>
//         </div>

//         {/* Social Media */}
//         <div className="flex-1 min-w-[180px]">
//           <h4 className="text-base font-semibold mb-3 text-[#9BA4B5]">Follow Us</h4>
//           <div className="flex gap-4">
//             <a href="#" className="w-9 h-9 flex items-center justify-center bg-[#394867] text-[#F1F6F9] rounded-full transition-all hover:scale-110 hover:bg-[#9BA4B5] hover:text-[#212A3E]">
//               <FaFacebookF />
//             </a>
//             <a href="#" className="w-9 h-9 flex items-center justify-center bg-[#394867] text-[#F1F6F9] rounded-full transition-all hover:scale-110 hover:bg-[#9BA4B5] hover:text-[#212A3E]">
//               <FaTwitter />
//             </a>
//             <a href="#" className="w-9 h-9 flex items-center justify-center bg-[#394867] text-[#F1F6F9] rounded-full transition-all hover:scale-110 hover:bg-[#9BA4B5] hover:text-[#212A3E]">
//               <FaLinkedinIn />
//             </a>
//             <a href="#" className="w-9 h-9 flex items-center justify-center bg-[#394867] text-[#F1F6F9] rounded-full transition-all hover:scale-110 hover:bg-[#9BA4B5] hover:text-[#212A3E]">
//               <FaInstagram />
//             </a>
//           </div>
//         </div>
//       </div>

//       {/* Footer Bottom */}
//       <div className="text-center mt-8 border-t border-white/20 pt-4 text-sm text-[#9BA4B5]">
//         <p>© {new Date().getFullYear()} AI DPR Analysis System. All rights reserved.</p>
//       </div>
//     </footer>
//   );
// };

// export default Footer;




import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-slate-950 pt-16 pb-8 border-t border-slate-800 font-sans">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
        
        {/* Column 1 & 2: Brand & About (Spans 2 columns on large screens) */}
        <div className="col-span-1 lg:col-span-2">
          <h3 className="text-2xl font-bold text-white mb-4 tracking-tight">
            InfraVision
          </h3>
          <p className="text-slate-500 text-sm leading-relaxed max-w-sm mb-6">
            An AI-powered system to analyze Detailed Project Reports, predict risks,
            and provide actionable insights for smarter decision-making in public infrastructure.
          </p>
          
          {/* Social Icons - Styled to match the theme */}
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 text-slate-400 hover:bg-blue-600 hover:text-white transition-all duration-300">
              <FaFacebookF size={18} />
            </a>
            <a href="#" className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 text-slate-400 hover:bg-sky-500 hover:text-white transition-all duration-300">
              <FaTwitter size={18} />
            </a>
            <a href="#" className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 text-slate-400 hover:bg-blue-700 hover:text-white transition-all duration-300">
              <FaLinkedinIn size={18} />
            </a>
            <a href="#" className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 text-slate-400 hover:bg-pink-600 hover:text-white transition-all duration-300">
              <FaInstagram size={18} />
            </a>
          </div>
        </div>

        {/* Column 3: Quick Links */}
        <div>
          <h4 className="text-white font-semibold mb-6">Quick Links</h4>
          <ul className="space-y-3 text-slate-500 text-sm">
            <li>
              <Link to="/" className="hover:text-blue-400 transition-colors duration-200 block">Home</Link>
            </li>
            <li>
              <Link to="/dashboard" className="hover:text-blue-400 transition-colors duration-200 block">Dashboard</Link>
            </li>
            <li>
              <Link to="/upload" className="hover:text-blue-400 transition-colors duration-200 block">Upload DPR</Link>
            </li>
            <li>
              <Link to="/reports" className="hover:text-blue-400 transition-colors duration-200 block">All Reports</Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-blue-400 transition-colors duration-200 block">Login</Link>
            </li>
          </ul>
        </div>

        {/* Column 4: Contact Info */}
        <div>
          <h4 className="text-white font-semibold mb-6">Contact Us</h4>
          <ul className="space-y-4 text-slate-500 text-sm">
            <li className="flex flex-col">
              <span className="text-slate-400 font-medium mb-1">Email</span>
              <a href="mailto:support@infravision.com" className="hover:text-blue-400 transition-colors">
                support@infravision.com
              </a>
            </li>
            <li className="flex flex-col">
              <span className="text-slate-400 font-medium mb-1">Phone</span>
              <span className="hover:text-white transition-colors">+91 98765 43210</span>
            </li>
            <li className="flex flex-col">
              <span className="text-slate-400 font-medium mb-1">Address</span>
              <span>123 AI Tech Street,<br />Baroda, India</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-slate-900/50 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="text-slate-600 text-sm text-center md:text-left">
          &copy; {new Date().getFullYear()} InfraVision AI System. All rights reserved.
        </div>
        <div className="flex gap-6 text-sm text-slate-600">
            <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-blue-400 transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;