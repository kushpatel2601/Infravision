import React from "react";
import { 
  MapPin, 
  ArrowRight, 
  CheckCircle, 
  AlertTriangle, 
  Calendar,
  Building2,
  IndianRupee 
} from "lucide-react";

const DPRCard = ({ tender,onClick }) => {
  const data = tender.extractedData || {};
  const risk = tender.riskAnalysis || { score: 0 };
  
  // Helper for Score Badge Color
  const getScoreColor = (score) => {
    if (score >= 80) return "text-emerald-400 border-emerald-500/20 bg-emerald-500/10";
    if (score >= 50) return "text-amber-400 border-amber-500/20 bg-amber-500/10";
    return "text-rose-400 border-rose-500/20 bg-rose-500/10";
  };

  const scoreColor = getScoreColor(risk.score);

  return (
    <div 
      className="group bg-slate-900/60 backdrop-blur-md border border-slate-800 hover:border-sky-500/30 rounded-2xl p-6 transition-all duration-300 hover:shadow-2xl hover:shadow-sky-500/10 hover:-translate-y-1 flex flex-col justify-between h-full"
    >
      <div>
        {/* Top Row: Date & Score */}
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500 bg-slate-950 px-2.5 py-1 rounded-md border border-slate-800/50">
            <Calendar className="w-3 h-3" />
            {new Date(tender.createdAt).toLocaleDateString()}
          </div>
          
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${scoreColor}`}>
            {risk.score >= 80 ? <CheckCircle className="w-3 h-3"/> : <AlertTriangle className="w-3 h-3"/>}
            Score: {risk.score}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold text-slate-100 mb-2 line-clamp-2 group-hover:text-sky-400 transition-colors">
          {data.project_name || "Untitled Project"}
        </h3>

        {/* Details List */}
        <div className="space-y-3 mb-6">
          {/* Location */}
          <div className="flex items-start gap-2 text-sm text-slate-400">
            <MapPin className="w-4 h-4 shrink-0 mt-0.5 text-slate-600 group-hover:text-sky-500/70 transition-colors" />
            <span className="line-clamp-1">{data.location || "Location not specified"}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mt-3">
             {/* Area */}
            <div className="bg-slate-950/50 p-2 rounded-lg border border-slate-800/50 flex flex-col">
               <div className="flex items-center gap-1 text-[10px] text-slate-500 uppercase font-semibold mb-1">
                 <Building2 className="w-3 h-3" />Carpet Area (sq.ft)
               </div>
               <span className="text-slate-300 text-sm font-medium truncate">
                 {data.total_built_up_area || "N/A"}
               </span>
            </div>

            {/* Cost */}
            <div className="bg-slate-950/50 p-2 rounded-lg border border-slate-800/50 flex flex-col">
               <div className="flex items-center gap-1 text-[10px] text-slate-500 uppercase font-semibold mb-1">
                 <IndianRupee className="w-3 h-3" />Total Cost
               </div>
               <span className="text-emerald-400 text-sm font-mono font-bold truncate">
                 {data.cost_grand_total ? `${data.cost_grand_total} Cr` : "N/A"}
               </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={() => onClick(tender)}
        className="w-full mt-auto flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 py-3 rounded-xl font-medium transition-colors border border-slate-700 group-hover:border-slate-600 group-hover:bg-slate-700/80"
      >
        View Analysis
        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
      </button>
    </div>
  );
};

export default DPRCard;