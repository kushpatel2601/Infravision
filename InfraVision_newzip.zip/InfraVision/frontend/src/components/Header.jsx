// // import { useState, useEffect, useRef } from "react";
// // import { Link, useNavigate, useLocation } from "react-router-dom";
// // import {
// //   FaUserCircle,
// //   FaCog,
// //   FaSignOutAlt,
// //   FaChevronDown,
// //   FaUser
// // } from "react-icons/fa";

// // const Header = () => {
// //   const [isLoggedIn, setIsLoggedIn] = useState(false);
// //   const [userInfo, setUserInfo] = useState({ name: "", profilePic: "" });
// //   const [isDropdownOpen, setIsDropdownOpen] = useState(false);

// //   const navigate = useNavigate();
// //   const location = useLocation();
// //   const dropdownRef = useRef(null);

// //   // --- 1. Central Function to Check Login Status ---
// //   const checkLoginStatus = () => {
// //     const token = localStorage.getItem("token");
// //     if (token) {
// //       setIsLoggedIn(true);
// //       setUserInfo({
// //         name: localStorage.getItem("userName") || "User",
// //         profilePic: localStorage.getItem("userProfilePic") || ""
// //       });
// //     } else {
// //       setIsLoggedIn(false);
// //       setUserInfo({ name: "", profilePic: "" });
// //     }
// //   };

// //   // --- 2. NEW: Auto-Logout when visiting Home Page ---
// //   useEffect(() => {
// //     if (location.pathname === "/") {
// //       // Clear session data
// //       localStorage.clear();

// //       // Reset State
// //       setIsLoggedIn(false);
// //       setUserInfo({ name: "", profilePic: "" });
// //       setIsDropdownOpen(false);

// //       // We DO NOT navigate to '/login' here.
// //       // We want the user to see the Home page, just in a logged-out state.
// //     } else {
// //       // If not on home page, check if we are logged in
// //       checkLoginStatus();
// //     }
// //   }, [location.pathname]); // This runs every time the URL changes

// //   // --- 3. General Event Listeners (for tabs/other components) ---
// //   useEffect(() => {
// //     window.addEventListener("authChange", checkLoginStatus);
// //     window.addEventListener("storage", checkLoginStatus);

// //     const handleClickOutside = (event) => {
// //       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
// //         setIsDropdownOpen(false);
// //       }
// //     };
// //     document.addEventListener("mousedown", handleClickOutside);

// //     return () => {
// //       window.removeEventListener("authChange", checkLoginStatus);
// //       window.removeEventListener("storage", checkLoginStatus);
// //       document.removeEventListener("mousedown", handleClickOutside);
// //     };
// //   }, []);

// //   // --- 4. Manual Logout (Dropdown Button) ---
// //   const handleLogout = () => {
// //     localStorage.clear();
// //     setIsLoggedIn(false);
// //     setUserInfo({ name: "", profilePic: "" });
// //     setIsDropdownOpen(false);

// //     window.dispatchEvent(new CustomEvent("authChange"));

// //     navigate("/"); // Manual logout redirects to Login page
// //   };

// //   return (
// //     <header className="sticky top-0 z-50 w-full flex flex-wrap md:flex-nowrap justify-between items-center bg-[#212A3E] text-[#F1F6F9] px-6 py-4 shadow-md">

// //       {/* Logo Section */}
// //       <div className="text-2xl font-bold">
// //         <Link
// //           to="/"
// //           className="transition-transform transform hover:scale-105 hover:text-[#9BA4B5] duration-300"
// //         >
// //           InfraVision
// //         </Link>
// //       </div>

// //       {/* Navigation / User Section */}
// //       <nav className="flex items-center gap-6 flex-wrap justify-center mt-2 md:mt-0">

// //         {isLoggedIn ? (
// //           <div className="relative" ref={dropdownRef}>

// //             {/* Trigger Button */}
// //             <button
// //               onClick={() => setIsDropdownOpen(!isDropdownOpen)}
// //               className="flex items-center gap-3 focus:outline-none hover:bg-[#394867] p-2 rounded-lg transition-all duration-300"
// //             >
// //               {userInfo.profilePic ? (
// //                 <img
// //                   src={userInfo.profilePic}
// //                   alt="Profile"
// //                   className="w-10 h-10 rounded-full object-cover border-2 border-[#9BA4B5]"
// //                 />
// //               ) : (
// //                 <div className="w-10 h-10 rounded-full bg-[#394867] border-2 border-[#9BA4B5] flex items-center justify-center text-lg font-bold text-[#F1F6F9]">
// //                    {userInfo.name ? userInfo.name.charAt(0).toUpperCase() : "U"}
// //                 </div>
// //               )}

// //               <div className="hidden sm:flex items-center gap-2">
// //                 <span className="font-medium text-[#F1F6F9]">
// //                   {userInfo.name}
// //                 </span>
// //                 <FaChevronDown className={`text-xs transition-transform duration-200 ${isDropdownOpen ? "rotate-180" : ""}`} />
// //               </div>
// //             </button>

// //             {/* Dropdown Menu */}
// //             {isDropdownOpen && (
// //               <div className="absolute right-0 mt-2 w-48 bg-[#394867] border border-gray-600 rounded-lg shadow-xl overflow-hidden z-50 animate-fadeIn">

// //                 <Link
// //                   to="/profile"
// //                   onClick={() => setIsDropdownOpen(false)}
// //                   className="flex items-center px-4 py-3 text-sm text-[#F1F6F9] hover:bg-[#212A3E] transition"
// //                 >
// //                   <FaUser className="mr-3" /> Profile
// //                 </Link>

// //                 <Link
// //                   to="/settings"
// //                   onClick={() => setIsDropdownOpen(false)}
// //                   className="flex items-center px-4 py-3 text-sm text-[#F1F6F9] hover:bg-[#212A3E] transition"
// //                 >
// //                   <FaCog className="mr-3" /> Settings
// //                 </Link>

// //                 <div className="border-t border-gray-600 my-1"></div>

// //                 <button
// //                   onClick={handleLogout}
// //                   className="flex items-center w-full px-4 py-3 text-sm text-red-300 hover:bg-[#212A3E] hover:text-red-400 transition"
// //                 >
// //                   <FaSignOutAlt className="mr-3" /> Logout
// //                 </button>
// //               </div>
// //             )}
// //           </div>
// //         ) : (
// //           // Login Button (Shown when logged out)
// //           <Link
// //             to="/login"
// //             className="bg-[#394867] text-[#F1F6F9] px-5 py-2 rounded-lg font-semibold transition-all duration-300 hover:bg-[#9BA4B5] hover:text-[#212A3E] hover:scale-105"
// //           >
// //             Login
// //           </Link>
// //         )}
// //       </nav>
// //     </header>
// //   );
// // };

// // export default Header;






import { useState, useEffect, useRef } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  FaUserCircle,
  FaCog,
  FaSignOutAlt,
  FaChevronDown,
  FaUser,
} from "react-icons/fa";

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState({ name: "", profilePic: "" });
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();
  const dropdownRef = useRef(null);

  // --- 1. Central Function to Check Login Status ---
  const checkLoginStatus = () => {
    const token = localStorage.getItem("token");
    if (token) {
      setIsLoggedIn(true);
      setUserInfo({
        name: localStorage.getItem("userName") || "User",
        profilePic: localStorage.getItem("userProfilePic") || "",
      });
    } else {
      setIsLoggedIn(false);
      setUserInfo({ name: "", profilePic: "" });
    }
  };

  // --- 2. Auto-Logout when visiting Home Page ---
  useEffect(() => {
    if (location.pathname === "/") {
      // Clear session data
      localStorage.clear();

      // Reset State
      setIsLoggedIn(false);
      setUserInfo({ name: "", profilePic: "" });
      setIsDropdownOpen(false);

      // We DO NOT navigate to '/login' here.
    } else {
      // If not on home page, check if we are logged in
      checkLoginStatus();
    }
  }, [location.pathname]);

  // --- 3. General Event Listeners ---
  useEffect(() => {
    window.addEventListener("authChange", checkLoginStatus);
    window.addEventListener("storage", checkLoginStatus);

    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      window.removeEventListener("authChange", checkLoginStatus);
      window.removeEventListener("storage", checkLoginStatus);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // --- 4. Manual Logout (Dropdown Button) ---
  const handleLogout = () => {
    localStorage.clear();
    setIsLoggedIn(false);
    setUserInfo({ name: "", profilePic: "" });
    setIsDropdownOpen(false);

    window.dispatchEvent(new CustomEvent("authChange"));

    navigate("/"); // Manual logout redirects to Login page
  };

  return (
    // THEME UPDATE: Dark Slate Background with Blur
    <header className="sticky top-0 z-50 w-full flex flex-wrap md:flex-nowrap justify-between items-center bg-slate-950 border-b border-slate-900/60 text-slate-100 px-6 py-4 shadow-lg shadow-slate-950/20">
      {/* Logo Section */}
      <div className="text-2xl font-bold">
        <Link to="/" className="flex items-center gap-2 group">
          {/* THEME UPDATE: Gradient Text Logo */}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400 group-hover:from-blue-300 group-hover:to-sky-300 transition-all duration-300">
            InfraVision
          </span>
        </Link>
      </div>

      {/* Navigation / User Section */}
      <nav className="flex items-center gap-6 flex-wrap justify-center mt-2 md:mt-0">
        {isLoggedIn ? (
          <div className="relative" ref={dropdownRef}>
            {/* Trigger Button */}
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-3 focus:outline-none hover:bg-white/5 border border-transparent hover:border-white/10 p-2 rounded-lg transition-all duration-300"
            >
              {userInfo.profilePic ? (
                <img
                  src={userInfo.profilePic}
                  alt="Profile"
                  className="w-10 h-10 rounded-full object-cover border border-slate-600"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-lg font-bold text-sky-400">
                  {userInfo.name ? userInfo.name.charAt(0).toUpperCase() : "U"}
                </div>
              )}

              <div className="hidden sm:flex items-center gap-2">
                <span className="font-medium text-slate-200">
                  {userInfo.name}
                </span>
                <FaChevronDown
                  className={`text-xs text-slate-400 transition-transform duration-200 ${
                    isDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </div>
            </button>

            {/* Dropdown Menu */}
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50 animate-fadeIn">
                <div className="px-4 py-3 border-b border-slate-800">
                  <p className="text-sm text-slate-400">Signed in as</p>
                  <p className="text-sm font-semibold text-white truncate">
                    {userInfo.name}
                  </p>
                </div>

                <Link
                  to="/profile"
                  onClick={() => setIsDropdownOpen(false)}
                  className="flex items-center px-4 py-3 text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
                >
                  <FaUser className="mr-3 text-sky-500" /> Profile
                </Link>

                <Link
                  to="/settings"
                  onClick={() => setIsDropdownOpen(false)}
                  className="flex items-center px-4 py-3 text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
                >
                  <FaCog className="mr-3 text-sky-500" /> Settings
                </Link>

                <div className="border-t border-slate-800 my-1"></div>

                <button
                  onClick={handleLogout}
                  className="flex items-center w-full px-4 py-3 text-sm text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-colors"
                >
                  <FaSignOutAlt className="mr-3" /> Logout
                </button>
              </div>
            )}
          </div>
        ) : (
          // Login Button (Shown when logged out)
          <Link
            to="/login"
            className="px-6 py-2.5 rounded-lg font-semibold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-500/20 hover:-translate-y-0.5 transition-all duration-300"
          >
            Login
          </Link>
        )}
      </nav>
    </header>
  );
};

export default Header;









// import { useState, useEffect, useRef } from "react";
// import { Link, useNavigate, useLocation } from "react-router-dom";
// // Using Lucide React for a clean, modern UI
// import { 
//   LayoutDashboard, 
//   FileText, 
//   AlertTriangle, 
//   Activity, 
//   Bell, 
//   Search, 
//   ChevronDown, 
//   User, 
//   Settings, 
//   LogOut 
// } from 'lucide-react';

// const Header = () => {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [userInfo, setUserInfo] = useState({ name: "", profilePic: "" });
//   const [isDropdownOpen, setIsDropdownOpen] = useState(false);

//   const navigate = useNavigate();
//   const location = useLocation();
//   const dropdownRef = useRef(null);

//   // --- 1. Central Function to Check Login Status ---
//   const checkLoginStatus = () => {
//     const token = localStorage.getItem("token");
//     if (token) {
//       setIsLoggedIn(true);
//       setUserInfo({
//         name: localStorage.getItem("userName") || "User",
//         profilePic: localStorage.getItem("userProfilePic") || "",
//       });
//     } else {
//       setIsLoggedIn(false);
//       setUserInfo({ name: "", profilePic: "" });
//     }
//   };

//   // --- 2. Auto-Logout when visiting Home Page ---
//   useEffect(() => {
//     if (location.pathname === "/") {
//       localStorage.clear();
//       setIsLoggedIn(false);
//       setUserInfo({ name: "", profilePic: "" });
//       setIsDropdownOpen(false);
//     } else {
//       checkLoginStatus();
//     }
//   }, [location.pathname]);

//   // --- 3. General Event Listeners ---
//   useEffect(() => {
//     window.addEventListener("authChange", checkLoginStatus);
//     window.addEventListener("storage", checkLoginStatus);

//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setIsDropdownOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);

//     return () => {
//       window.removeEventListener("authChange", checkLoginStatus);
//       window.removeEventListener("storage", checkLoginStatus);
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   // --- 4. Manual Logout ---
//   const handleLogout = () => {
//     localStorage.clear();
//     setIsLoggedIn(false);
//     setUserInfo({ name: "", profilePic: "" });
//     setIsDropdownOpen(false);
//     window.dispatchEvent(new CustomEvent("authChange"));
//     navigate("/"); 
//   };

//   // --- 5. Helper for Dashboard Navigation Links (THEME UPDATE: Slate Styles) ---
//   const NavLink = ({ icon, text, to = "#" }) => (
//     <Link 
//       to={to} 
//       className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-slate-300 hover:bg-white/10 hover:text-white transition-colors"
//     >
//       <span className="mr-2">{icon}</span>
//       {text}
//     </Link>
//   );

//   return (
//     // THEME UPDATE: Unified "Original" Dark Slate Theme for both states
//     <header 
//       className="sticky top-0 z-50 w-full shadow-lg transition-all duration-300 bg-slate-950 text-slate-100 border-b border-slate-900/60 shadow-slate-950/20"
//     >
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <div className="flex items-center justify-between h-16">
          
//           {/* --- LEFT SIDE: Logo & Navigation --- */}
//           <div className="flex items-center gap-8">
//             {/* Logo */}
//             <div className="text-2xl font-bold">
//               <Link to={isLoggedIn ? "/" : "/"} className="flex items-center gap-2 group">
//                 {/* Unified Gradient Logo Style */}
//                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400 group-hover:from-blue-300 group-hover:to-sky-300 transition-all duration-300">
//                   {isLoggedIn ? "InfraVision" : "InfraVision"}
//                 </span>
//               </Link>
//             </div>

//             {/* Dashboard Navigation (Visible when Logged In) */}
//             {isLoggedIn && (
//               <div className="hidden md:flex items-baseline space-x-2">
//                 <NavLink icon={<LayoutDashboard size={16} />} text="Overview" to="/governor" />
//                 <NavLink icon={<FileText size={16} />} text="All DPRs" to="/governor/dprs" />
//                 <NavLink icon={<AlertTriangle size={16} />} text="High Risk" to="/high-risk" />
//                 <NavLink icon={<Activity size={16} />} text="AI Logs" to="/logs" />
//               </div>
//             )}
//           </div>

//           {/* --- RIGHT SIDE: Search, Bell, Profile --- */}
//           <div className="flex items-center gap-4">
            
//             {isLoggedIn ? (
//               // --- LOGGED IN VIEW (Original Theme Styling) ---
//               <>
//                 {/* Search Bar (Dark Theme) */}
//                 <div className="relative hidden md:block">
//                   <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
//                   <input 
//                     type="text" 
//                     placeholder="Search DPRs..." 
//                     className="pl-9 pr-4 py-1.5 bg-slate-900 border border-slate-800 rounded-full text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500 w-48 transition-all" 
//                   />
//                 </div>
                
//                 {/* Bell Icon */}
//                 <button className="relative p-2 text-slate-300 hover:text-white transition-colors">
//                   <Bell size={20} />
//                   <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
//                 </button>

//                 {/* Profile Dropdown Trigger (Dark Theme) */}
//                 <div className="relative" ref={dropdownRef}>
//                   <button
//                     onClick={() => setIsDropdownOpen(!isDropdownOpen)}
//                     className="flex items-center gap-2 pl-4 border-l border-slate-800 cursor-pointer focus:outline-none group"
//                   >
//                     <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-sky-400 border border-slate-700 group-hover:border-sky-400 transition-all">
//                       {userInfo.name ? userInfo.name.charAt(0).toUpperCase() : "G"}
//                     </div>
//                     <div className="hidden sm:block text-left">
//                       <p className="text-sm font-medium text-slate-200 group-hover:text-white transition-colors">
//                         {userInfo.name || "Hon. Governor"}
//                       </p>
//                     </div>
//                     <ChevronDown size={14} className={`text-slate-400 transition-transform ${isDropdownOpen ? "rotate-180" : ""}`} />
//                   </button>

//                   {/* Dropdown Menu (Dark Theme) */}
//                   {isDropdownOpen && (
//                     <div className="absolute right-0 mt-3 w-56 bg-slate-900 border border-slate-700 rounded-lg shadow-xl overflow-hidden z-50 animate-fadeIn">
//                       <div className="px-4 py-3 border-b border-slate-800">
//                         <p className="text-xs text-slate-500 uppercase">Signed in as</p>
//                         <p className="text-sm font-bold text-slate-100 truncate">{userInfo.name}</p>
//                       </div>

//                       <Link to="/profile" onClick={() => setIsDropdownOpen(false)} className="flex items-center px-4 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors">
//                         <User size={16} className="mr-2 text-sky-500" /> Profile
//                       </Link>
//                       <Link to="/settings" onClick={() => setIsDropdownOpen(false)} className="flex items-center px-4 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors">
//                         <Settings size={16} className="mr-2 text-sky-500" /> Settings
//                       </Link>
                      
//                       <div className="border-t border-slate-800 my-1"></div>
                      
//                       <button onClick={handleLogout} className="flex items-center w-full px-4 py-2 text-sm text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-colors">
//                         <LogOut size={16} className="mr-2" /> Logout
//                       </button>
//                     </div>
//                   )}
//                 </div>
//               </>
//             ) : (
//               // --- LOGGED OUT VIEW ---
//               <Link
//                 to="/login"
//                 className="px-6 py-2.5 rounded-lg font-semibold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-500/20 hover:-translate-y-0.5 transition-all duration-300"
//               >
//                 Login
//               </Link>
//             )}
//           </div>
//         </div>
//       </div>
//     </header>
//   );
// };

// export default Header;



