import React from 'react';

const ProjectTable = ({ projects, loading }) => {
  const RiskBadge = ({ score, label }) => {
    let colorStyles = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    if (score > 75) colorStyles = 'bg-rose-500/10 text-rose-400 border-rose-500/20';
    else if (score > 50) colorStyles = 'bg-amber-500/10 text-amber-400 border-amber-500/20';

    return (
      <span className={`px-3 py-1 rounded-md text-xs font-bold border ${colorStyles} inline-flex items-center gap-1.5`}>
        <span className={`w-1.5 h-1.5 rounded-full ${score > 75 ? 'bg-rose-400' : score > 50 ? 'bg-amber-400' : 'bg-emerald-400'}`}></span>
        {score}% {label}
      </span>
    );
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/40">
        <h3 className="text-lg font-bold text-slate-100">Priority Projects</h3>
        <button className="text-xs font-semibold text-sky-400 hover:text-sky-300">View All</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-950/50 text-slate-500 text-xs uppercase tracking-wider">
            <tr>
              <th className="px-6 py-4 font-semibold">Tender Ref / Project</th>
              <th className="px-6 py-4 font-semibold">Sector</th>
              <th className="px-6 py-4 font-semibold">Budget</th>
              <th className="px-6 py-4 font-semibold">AI Risk Score</th>
              <th className="px-6 py-4 font-semibold">AI Insight</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800 text-sm">
            {loading ? (
               [...Array(3)].map((_, i) => (
                 <tr key={i}>
                   <td colSpan="5" className="px-6 py-4">
                     <div className="h-8 bg-slate-800/50 rounded animate-pulse"></div>
                   </td>
                 </tr>
               ))
            ) : projects.slice(0, 8).map((project) => (
              <tr key={project.id} className="hover:bg-slate-800/30 transition-colors group">
                <td className="px-6 py-4">
                    <div className="font-medium text-slate-200 group-hover:text-sky-400 transition-colors">
                      {project.name}
                    </div>
                    <div className="text-xs text-slate-500 mt-1">{project.agency}</div>
                </td>
                <td className="px-6 py-4 text-slate-400">
                  <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-xs">
                    {project.sector}
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-300 font-mono tracking-tight">₹{project.budget}</td>
                <td className="px-6 py-4">
                  <RiskBadge score={project.risk} label={project.status} />
                </td>
                <td className="px-6 py-4 text-slate-500 truncate max-w-xs group-hover:text-slate-400 transition-colors" title={project.ai_insight}>
                  {project.ai_insight}
                </td>
              </tr>
            ))}
            {projects.length === 0 && !loading && (
                <tr><td colSpan="5" className="px-6 py-12 text-center text-slate-500">No project data found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProjectTable;