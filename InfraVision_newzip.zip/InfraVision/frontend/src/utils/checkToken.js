import jwtDecode from "jwt-decode";
import { logoutUser } from "./auth";

export const isTokenExpired = (token) => {
  try {
    const decoded = jwtDecode(token);
    const currentTime = Date.now() / 1000;

    if (decoded.exp < currentTime) {
      logoutUser();
      return true;
    }
    return false;
  } catch {
    logoutUser();
    return true;
  }
};
