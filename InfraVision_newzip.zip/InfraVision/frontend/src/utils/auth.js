export const getToken = () =>
  localStorage.getItem("token") || sessionStorage.getItem("token");

export const getUserType = () =>
  localStorage.getItem("userType") || sessionStorage.getItem("userType");

export const logoutUser = () => {
  localStorage.clear();
  sessionStorage.clear();
  document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
};
