import spacy
nlp = spacy.load("en_core_web_lg")
doc = nlp("The project cost is Rs. 250 crore approved by the court.")
print([(ent.text, ent.label_) for ent in doc.ents])
