from fastapi import FastAPI
from pydantic import BaseModel
import fitz
import pytesseract
import spacy

app = FastAPI()
nlp = spacy.load("en_core_web_sm")


class PdfInput(BaseModel):
    pdf_path: str


@app.post("/analyze")
def analyze_dpr(data: PdfInput):
    doc = fitz.open(data.pdf_path)

    metrics = {
        "pages": len(doc),
        "land_pages": 0,
        "environment_pages": 0,
        "money_mentions": 0,
        "legal_mentions": 0
    }

    for page in doc:
        pix = page.get_pixmap(dpi=300)
        text = pytesseract.image_to_string(pix.tobytes())
        t = text.lower()

        if "land acquisition" in t:
            metrics["land_pages"] += 1
        if "environmental clearance" in t:
            metrics["environment_pages"] += 1
        if "court" in t or "legal" in t:
            metrics["legal_mentions"] += 1

        doc_nlp = nlp(text)
        for ent in doc_nlp.ents:
            if ent.label_ == "MONEY":
                metrics["money_mentions"] += 1

    score = 0.2
    if metrics["land_pages"] > 15:
        score += 0.3
    if metrics["environment_pages"] > 10:
        score += 0.2
    if metrics["legal_mentions"] > 5:
        score += 0.2
    if metrics["money_mentions"] > 50:
        score += 0.1

    level = "LOW"
    if score > 0.7:
        level = "HIGH"
    elif score > 0.4:
        level = "MEDIUM"

    explanation = (
        "Risk is derived from land acquisition complexity, "
        "environmental clearances, legal exposure, "
        "and financial scale indicators."
    )

    return {
        "metrics": metrics,
        "risk_score": score,
        "risk_level": level,
        "explanation": explanation
    }
